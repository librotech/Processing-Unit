<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Sale;
use App\Expense;
use Auth;
use App\Ledger;
use Carbon\Carbon;
use DB;
use App\Product;
use App\Bill_product;
use App\Notification;
use App\Inventory;
// use App\Stichinv;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $this->expiry_date();


        $message="";
        $invquery=DB::raw('SELECT inventories.*,products.product_description FROM inventories left join products ON products.product_id=inventories.inv_product_id WHERE inventories.id IN ( SELECT MAX(inventories.id) FROM inventories GROUP BY inv_product_id)');
        $inventories =DB::select($invquery);
        // foreach($inventories as $inventory){
            
        //     if($inventory->inv_qty < $inventory->stock_alert){
        //        $message= $inventory->product_description."  Stock Alert Remaining Qty is ".$inventory->inv_qty."  And Stock Alert is  ".$inventory->stock_alert;
        //        $checkduplicate=Notification::where('message',$message)->count();
        //        if($checkduplicate == null){
        //         $notification=new Notification;
        //         $notification->message=$message;
        //         $notification->dismiss=false;
        //         $notification->save();
        //        }
                
        //     }

        // }

        $creditlimitquery=DB::raw('SELECT ledgers.balance,customers.customer_name,customers.credit_limit FROM ledgers left join customers ON customers.customer_id=substring_index(ledgers.account_id, "_", -1) WHERE ledgers.id IN ( SELECT MAX(ledgers.id) FROM ledgers GROUP BY account_id) && account_id LIKE "%customer_%"');
        $creditlimits =DB::select($creditlimitquery);
        // foreach($creditlimits as $creditlimit){
            
        //     if($creditlimit->balance > $creditlimit->credit_limit){
        //        $message= $creditlimit->customer_name." Credit Limit Crossed current credit balance is  ".$creditlimit->balance."  And Credit Limit was  ".$creditlimit->credit_limit;
        //        $checkduplicate=Notification::where('message',$message)->count();
        //        if($checkduplicate == null){
        //         $notification=new Notification;
        //         $notification->message=$message;
        //         $notification->dismiss=false;
        //         $notification->save();
        //        }
                
        //     }

        // }
        $incomes=0;
        $credit_sales=0;
        $cash_sales=0;
        $costofsales=0;
        $expenses=0;
        $query=0;
        $query2=0;
        $cosquery="";
        $totalcos=0;
        $revenue=0;
        $netprofit=0;
        $otheraccountbalancequery=0;
        $total_oaccblnc=0;
        $cashinhandquery=0;
        $total_cashinhand=0;
        $payablequery=0;
        $totalpayable=0;
        $recieveablequery=0;
        $totalrecieveable=0;
        $currentMonth = date('m');
        $topsoldproducts="";
        $topsoldqty="";
        $manual_sales="";
        // $credit_sales=Stichinv::sum('total');
        $manual_sales=Sale::sum('subtotal');
        $query=DB::raw('SELECT chartofaccounts.*,ledgers.balance FROM chartofaccounts left join ledgers ON chartofaccounts.coa_id=ledgers.account_id WHERE ledgers.id IN ( SELECT MAX(ledgers.id) FROM ledgers GROUP BY account_id) && ledgers.account_type=4 && ledgers.account_id !=10101');
        $incomes =DB::select($query);

        $query2=DB::raw('SELECT chartofaccounts.*,ledgers.balance FROM chartofaccounts left join ledgers ON chartofaccounts.coa_id=ledgers.account_id WHERE ledgers.id IN ( SELECT MAX(ledgers.id) FROM ledgers GROUP BY account_id) && ledgers.account_type=5 && account_id NOT LIKE "%ade_%" && account_id !="10102"');
        $expenses=DB::select($query2);
        $total_income=0;$total_expenses=0;
        foreach($incomes as $income){
                 $total_income +=$income->balance;  
            }
        foreach($expenses as $expense){
                $total_expenses +=$expense->balance;
            }
        $revenue=$credit_sales+$total_income+$manual_sales;

         $cosquery=DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date asc) x  where x.account_id="10102"  &&  MONTH(x.date) ='.date("m").'');

         $costofsales=DB::select($cosquery);
         foreach ($costofsales as $cos) {
              $totalcos =$cos->balance;
         }
         $netprofit = $credit_sales+$total_income-$totalcos-$total_expenses;

          $otheraccountbalancequery=DB::raw('SELECT ledgers.balance FROM  ledgers LEFT JOIN cprelations ON ledgers.account_id=cprelations.acc_id WHERE ledgers.id IN ( SELECT MAX(ledgers.id) FROM ledgers GROUP BY account_id) && ledgers.account_type=1 && account_id !="52"');
          $otheraccountbalances=DB::select($otheraccountbalancequery);
          foreach($otheraccountbalances as $otheraccountbalance){
                $total_oaccblnc +=$otheraccountbalance->balance;
            }
        $cashinhandquery=DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance FROM ledgers where ledgers.account_id=52 ORDER BY date asc) x');
          $cashinhands=DB::select($cashinhandquery);
          foreach($cashinhands as $cashinhand){
                $total_cashinhand =$cashinhand->balance;
            }
        $payablequery=DB::raw('SELECT ledgers.balance FROM ledgers WHERE ledgers.id IN ( SELECT MAX(ledgers.id) FROM ledgers GROUP BY account_id) && ledgers.account_type=2 && account_id LIKE "%supplier_%"');
            $payables=DB::select($payablequery);
            foreach ($payables as $payable) {
                $totalpayable +=$payable->balance;
            }
        $recieveablequery=DB::raw('SELECT ledgers.balance FROM ledgers WHERE ledgers.id IN ( SELECT MAX(ledgers.id) FROM ledgers GROUP BY account_id) && ledgers.account_type=1 && account_id LIKE "%customer_%"');
            $recieveables=DB::select($recieveablequery);
            foreach ($recieveables as $recieveable) {
                $totalrecieveable +=$recieveable->balance;
            }
            
            $jansaleincome=0;
            $fabsaleincome=0;
            $marchsaleincome=0;
            $aprilsaleincome=0;
            $maysaleincome=0;
            $junsaleincome=0;
            $julysaleincome=0;
            $augsaleincome=0;
            $sepsaleincome=0;
            $octsaleincome=0;
            $novsaleincome=0;
            $decsaleincome=0;
        
            $decexpense=Ledger::select('balance')->whereMonth('date',12)->where('account_id','10101')->orderby('date','desc')->first();
           //return $decexpense->balance;
            $janexpense=Ledger::select('balance')->whereMonth('date',1)->where('account_id','10101')->orderby('date','desc')->first();
            $fabexpense=Ledger::select('balance')->whereMonth('date',2)->where('account_id','10101')->orderby('date','desc')->first();
            $marchexpense=Ledger::select('balance')->whereMonth('date',3)->where('account_id','10101')->orderby('date','desc')->first();
            $aprilexpense=Ledger::select('balance')->whereMonth('date',4)->where('account_id','10101')->orderby('date','desc')->first();
            $mayexpense=Ledger::select('balance')->whereMonth('date',5)->where('account_id','10101')->orderby('date','desc')->first();
            $junexpense=Ledger::select('balance')->whereMonth('date',6)->where('account_id','10101')->orderby('date','desc')->first();
            $julyexpense=Ledger::select('balance')->whereMonth('date',7)->where('account_id','10101')->orderby('date','desc')->first();
            $augexpense=Ledger::select('balance')->whereMonth('date',8)->where('account_id','10101')->orderby('date','desc')->first();
            $sepexpense=Ledger::select('balance')->whereMonth('date',9)->where('account_id','10101')->orderby('date','desc')->first();
            $octexpense=Ledger::select('balance')->whereMonth('date',10)->where('account_id','10101')->orderby('date','desc')->first();
            $novexpense=Ledger::select('balance')->whereMonth('date',11)->where('account_id','10101')->orderby('date','desc')->first();
            //$decexpense=Expense::whereMonth('date',12)->sum('expense_amount');
            
            $soldqtyquery='';
            // return $soldqtyquery;
            $notification=Notification::where('dismiss',0)->count();
            
             $query=DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=1  OR x.account_type=6   GROUP BY account_id ORDER BY x.account_type ASC');
         $assets=DB::select($query);
        return view('home',compact('credit_sales','cash_sales','total_expenses','revenue','netprofit','total_oaccblnc','total_cashinhand','totalpayable','totalrecieveable','jansaleincome','fabsaleincome','marchsaleincome','aprilsaleincome','maysaleincome','junsaleincome','julysaleincome','augsaleincome','sepsaleincome','octsaleincome','novsaleincome','decsaleincome','janexpense','fabexpense','marchexpense','aprilexpense','mayexpense','junexpense','julyexpense','augexpense','sepexpense','octexpense','novexpense','decexpense','soldqtyquery','notification','totalcos','assets'));
    }

    public function notification(){

        $notification=Notification::where('dismiss',0)->orderby('id','desc')->paginate(30);
        return view('notifications',['notification'=>$notification]);
    }

    public function dismiss($notification_id){
        $update=Notification::where('id',$notification_id)->update(['dismiss'=>true]);
        if($update){
            return redirect('notification');
        }
    }

    public function expiry_date(){

        $now = Carbon::now()->addDays(30);
        // $bill_data  = Bill_product::all();
        $product =Bill_Product::groupBy('expiry_date')
        ->whereDate('expiry_date', '<', $now->toDateString())
        ->get();


        // foreach($product as $pro){
        // $message="Product ID:".$pro->product_id." is about to Expire  on Date: ".$pro->expiry_date."   ";
        // $checkduplicate=Notification::where('message',$message)->count();
        // if($checkduplicate == null){
        //     $notification=new Notification;
        //     $notification->message=$message;
        //     $notification->dismiss=false;
        //     $notification->save();
        //         }
        //     }

        }

    
}
