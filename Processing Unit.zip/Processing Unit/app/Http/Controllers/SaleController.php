<?php

namespace App\Http\Controllers;

use App\Sale;
use Illuminate\Http\Request;
use App\Customer;
use App\product;
use App\Saleproduct;
use DB;
use App\Inventory;
use App\ledger;
use Auth;
use Session;
use App\Cashrecieved;
use App\Cashrecievedproduct;
use App\Fiscalyear;
use App\byproducts;
use App\Supplier;
use App\Chartofaccount;
use App\Employee;

class SaleController extends Ledgerfunctions
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    Public function __construct(){
         //check if user lgged in
        $this->middleware('auth');
    }
    //index function to show all sales
    public function index()
    {
       $query=DB::raw('SELECT sales.*,customers.customer_name,users.name From sales LEFT JOIN customers ON sales.customer=customers.customer_id LEFT JOIN users ON sales.user_id = users.id where void=false');
         $sales=DB::select($query);

      return view('sale/view' , compact('sales'));
    }
    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $fy=Fiscalyear::orderby('id','desc')->first();
        if($fy != null){
        $fy=date('20y,m,d', strtotime($fy->fy.'-1 year'));
        }
        else{
            $fy='2017,12,5';
        }
        //all customers from customers table
        $customers=Customer::orderByRaw("FIELD(customer_name ,'Like', 'Walk') ASC")->get();
        $walkincus=Customer::orderByRaw("FIELD(customer_name ,'Like', 'Walk') ASC")->first();
        //chart of accounts from cprelation table
        $chartofaccounts=DB::table('cprelations')->select('cprelations.*','chartofaccounts.account_type')->leftjoin('chartofaccounts','chartofaccounts.coa_id','cprelations.acc_id')->orderByRaw("FIELD(def ,1) DESC")->get();
        //Auto increment to add new invoice with new id
        $auto_increment=DB::select("SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA ='rice' AND TABLE_NAME ='sales'");
        //all products from products table
        // $products=Product::all();
        $products=Inventory::leftjoin('products','products.product_id','=','inventories.inv_product_id')->groupby('inv_product_id')->get();

        
        return view('sale.add',compact('customers','products','auto_increment','chartofaccounts','walkincus','fy'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

       //here validating empty fields
        $this->validate($request,
            ['txt_customer_id'=>'required']);
        $transectiontype=2;
         //storing data in database table sales
        $sale=new Sale;
        $sale->customer=$request->txt_customer_id;
        $sale->date=$request->txt_date;
        $sale->subtotal=$request->total; 
        $sale->discount=$request->discount;
        $sale->cashpaid=$request->cash_paid;
        $sale->duebalance=$request->total_amount;
        $sale->coa=$request->coa;
        $sale->void=false;
        $sale->user_id=Auth::id();
        //checking if it was a credit sale or not
        if(isset($request->creditsale)){
            $sale->credit_sales=true;
        }
        else{
            $sale->credit_sales=false;
        }
        //checking if sales data saved successfully and proceed
        if($sale->save())
        {
        //$reference id variable to refrence ledger entries
       $refrence_id=$request->txt_inv_no;
         //if credit sale check box is checked
        if(isset($request->creditsale)){
        $this->credit_sale_ladger('customer_'.$request->txt_customer_id,$request->total_amount,$refrence_id,$transectiontype,$request->txt_date,$request->date_bit);
        }
       $this->cashpaidledger($request->coa,$request->cash_paid,$refrence_id,$transectiontype,$request->txt_date,$request->date_bit);

       $finalarray = array();
       $tempprice=0;
       $tempqty=0;
       $tempresult=0;
       $tempamount=0;
       $arr_productid      =  $request->txt_product;
       $arr_productid[]    =  $request->txt_product_id1;
       $arr_byproduct      =  $request->txt_byproduct_id;
       $arr_byproduct[]    =  $request->txt_byproduct_id1;
       $arr_productprice   =  $request->price;
       $arr_productprice[] =  $request->price1;
       $arr_price          =  $request->p_price;
       $arr_price[]        =  $request->p_price1;
       $arr_productqty     =  $request->tqty;
       $arr_productqty[]   =  $request->tqty1;
       $arr_bags           =  $request->bags;
       $arr_bags[]         =  $request->bags1;
       $arr_inlintotal     =  $request->linetotal;
       $arr_inlintotal[]   =  $request->linetotal1;
       

       $count=count($arr_productid);
       $arr_flag = array();

       //creating flag element in array
       for ($i = 0; $i < count($arr_productid); $i++){
            $arr_flag[$i] = 0;
       }
       // for ($i = 0; $i < count($arr_productid); $i++){
       //          echo $arr_productid[$i] . "&nbsp;" . $arr_productprice[$i] . "&nbsp;" . $arr_productqty[$i]  . "&nbsp;" . $arr_flag[$i];
       //              echo "<br>";
       // }
       //              echo "Data Begins";
       //              echo "<br>";
       //looping through product arrays to sum up qty and price of same product_id

       $_costofsale = 0;

       for ($i = 0; $i < count($arr_productid); $i++){
                    $saleproducts=new Saleproduct;
                    $saleproducts->inv_id=$request->txt_inv_no;
                    $saleproducts->description=$arr_productid[$i];
                    $saleproducts->byproduct = $arr_byproduct[$i];
                    $saleproducts->sale_price=$arr_productprice[$i];
                    $saleproducts->cost_price=$arr_price[$i];
                    $saleproducts->qty=$arr_productqty[$i];
                    $saleproducts->inlinetotal=$arr_inlintotal[$i];
                    $saleproducts->save();

                    $sum = $arr_price[$i]*($arr_productqty[$i]/40);


                    $this->assetledger('product_1'.$arr_byproduct[$i],1,"assets",null,$sum,$transectiontype,$refrence_id,$request->txt_date);
                    $this->update_inventory($arr_byproduct[$i],$arr_productid[$i],$arr_bags[$i],$refrence_id,$request->total,$_costofsale,$request->txt_date,$request->date_bit);
                    $this->cost_sale_ledger($sum,$refrence_id,$request->txt_date,$request->date_bit);
                    // $this->update_inventory($arr_productqty[$i],$refrence_id,$request->total,$_costofsale,$request->txt_date,$request->date_bit);
        //temp id storing first itrations product id
            // $tempid = $arr_productid[$i];
            //loop again to track same product id
            // for($j = 0; $j < count($arr_productid); $j++){
            //     //checking if fileds are not empty to avoid store null data
            //     if($arr_productid[$j] != ""){
            //         //checking if first itrations product id is equal to second itrations product id and flag is not equal to 1
            //     if($arr_productid[$j] == $tempid && $arr_flag[$j] != 1){
            //         //summing up qty of same products
            //         $tempqty += $arr_productqty[$j];
            //         //summing up inline ammount of same products
            //         $tempamount +=$arr_inlintotal[$i];
            //          //getting price of each product
            //         $tempprice = $arr_productprice[$j];

            //         $tempbyproduct  = $arr_byproduct[$j];

            //         $arr_flag[$j] = 1;
            //     }
            //     }
            // }
            // if ($tempqty != 0){
            //     //checking if fileds are not empty to avoid store null data
            //     if($arr_productid[$i] !="" && $tempprice !="" && $tempqty !=""){
            //         //add sale products

                    
            //         //update inventory by calling "update_inventory" function
                    

            //         $tempqty = 0;
            //         $tempprice = 0;
            //         $tempamount=0;
            //     }
            // }
       }

        if(isset($request->discount)){
        $this->sale_ledger($request->discount_total,$refrence_id,$request->txt_date,$request->date_bit);
        }else{

            $this->sale_ledger($request->total,$refrence_id,$request->txt_date,$request->date_bit);
        }

        
        $request->session()->flash('message.level', 'success');
        $request->session()->flash('message.content', 'New Sale Has Been Added');
        }
       // echo "<script>window.open('alert:id=".$refrence_id."', '_blank')</script>";
        // echo "<script>window.open('http://127.0.0.1:8000/sale/add','self')</script>";
        return redirect('sale/add');
        
          
    }
    //Sale Print Function To Return All Fields as Json
    public function printsale($inv_id){
        $a= Sale::select('sales.id','sales.date','sales.date','sales.subtotal','sales.cashpaid','sales.duebalance','customers.customer_name')->leftjoin('customers','customers.customer_id','=','sales.customer')->where('sales.id',$inv_id)->get();
        $a .=Saleproduct::select('saleproducts.sale_price','saleproducts.qty','saleproducts.inlinetotal','products.product_description')->leftjoin('products','products.product_id','=','saleproducts.product')->where('inv_id',$inv_id)->get();
        return $a;
        // print_r($request);
        // $stringarray="";
        // // $stringarray .= "['invoice': '".$request->invno."', 'Dated': '".$request->invdate."','Customer': '".$request->invcustomer."', 'Total': '".$request->total."'],";
        // for($i=0;$i < count($request->product); $i++){
        //     $stringarray .='["product" =>"'.$request->description[$i].'","qty"=>'.$request->qty[$i].',"price"=>'.$request->price[$i].'],';
            
        // }
        // $stringarray =substr_replace($stringarray, '', -1);
        // header("Content-type: application/json");
        // $data=json_encode(array($stringarray));
        // return view('sale.print',compact('data'));
    }
   //update inventory in this "update_inventory" function
    public function update_inventory($by_id,$product_id,$qty,$refrence_id,$total, &$_costofsale,$date,$datebit){

         // echo 'product_id&nbsp'.$product_id."&nbsp  Quantity&nbsp".$qty."<br>";
        //updated at date formate
         $updated_at=date('Y-m-d H:i:s');
         $fin=0;
         $costofsale=0;
         $fin2=0;
         $input_qty=$qty;
         $res_price=0;
         $originalqty=0;
         // $wholeqty =Inventory::where('inv_product_id',$by_id)->sum('inv_qty');
         $wholebyqty =Inventory::where('inv_by_product_id',$by_id)->sum('inv_qty');
         $dbcp=0;
         //getting inventories
         $inventories=Inventory::where('inv_by_product_id',$by_id)->get();
         foreach ($inventories as $inventory) {
            //storing inventory id in $inventory_id
             $inventory_id=$inventory->id;
            //checking if sold item quantot is less then qty available in inventory agaainst that product
           if($inventory->inv_qty > $qty && $qty != 0 || $inventory->inv_qty == $qty && $qty != 0){
                //updated qty
                $final_qty=$inventory->inv_qty-$qty;
                //updated inventory of particular product with final_qty in below query
                $dbcp=$inventory->inv_cost_price;
                DB::table('inventories')->where('id',$inventory->id)->update(['inv_qty'=>$final_qty,'updated_at'=>$updated_at]);

                //empting sold product qty
                $qty=$qty-$qty;
               
            }
             //checking if sold item quantot is greater then qty available in inventory agaainst that product
            elseif($inventory->inv_qty < $qty) {
                //updated qty
                  $final_qty=$inventory->inv_qty-$inventory->inv_qty;
                  
                  //updated inventory of particular product with $final_qty in below query
                 DB::table('inventories')->where('id',$inventory->id)->update(['inv_qty'=>$final_qty,'updated_at'=>$updated_at]);

                 //summing up qty
                $originalqty +=$inventory->inv_qty;
                //sutracting sold qty from available qty
                $qty=$qty-$inventory->inv_qty;
                //getting last product ledger
                
               
                    $dbcp=$inventory->inv_cost_price;
                   //calculating resulting price
                  $res_price += $inventory->inv_qty*$inventory->inv_cost_price;
            }
            
            
           //echo 'price ='.$fin."<br>";
                
              }
              //echo $wholeqty."<br>";
           // if($input_qty > $wholeqty){

           //  $minus_quantity=$wholeqty-$input_qty;
           //  $last_record=DB::table('inventories')->where('inv_product_id',$product_id)->orderby('id', 'desc')->first();
           //    DB::table('inventories')->where('id',$last_record->id)->update(['inv_qty'=>$minus_quantity,'updated_at'=>$updated_at]);
              
           //  }

              if($input_qty > $wholebyqty){

                $minus_quantity=$wholebyqty-$input_qty;
            $last_record1=DB::table('inventories')->where('inv_by_product_id',$by_id)->orderby('id', 'desc')->first();
                //updated inventory of particular product with $minus_quantity in below query
               DB::table('inventories')->where('id',$last_record1->id)->update(['inv_qty'=>$minus_quantity,'updated_at'=>$updated_at]);
               }
            
        // //calculating final price
        $fin =$res_price+($input_qty-$originalqty)*$dbcp;
            $_costofsale +=$fin;
        //   //echo $fin;
        // //storing inventory ledger by calling inventoryledger function
        // $this->inventoryledger("product_".$product_id,$fin,$refrence_id,$date,$datebit);
        
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\Sale  $sale
     * @return \Illuminate\Http\Response
     */
    public function show($sale)
    {
         $sales=Sale::leftjoin('customers','sales.customer','customers.customer_id')->Where('sales.id',$sale)->get();
         $saleproducts=Saleproduct::select('saleproducts.*','products.product_id','products.product_description','finalized_products.product_id','finalized_products.name')->leftjoin('products','saleproducts.description','products.product_id')->leftjoin('finalized_products','saleproducts.byproduct','finalized_products.product_id')->Where('saleproducts.inv_id',$sale)->groupby('finalized_products.product_id')->get();
         // $salebyproducts=Saleproduct::select('saleproducts.*')->Where('saleproducts.inv_id',$sale)->get();
         // return $salebyproducts;
         return view('sale/edit',compact('sales','saleproducts','salebyproducts'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Sale  $sale
     * @return \Illuminate\Http\Response
     */
    public function edit(Sale $sale)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Sale  $sale
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Sale $sale)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Sale  $sale
     * @return \Illuminate\Http\Response
     */
    public function destroy($sale)
    {
        //deleting sales and sales products
       Sale::where('id',$sale)->delete();
        Saleproduct::where('inv_id',$sale)->delete();
        return redirect('sale/show');
    }

    //making sale invisible 
    public function voidsale($sale){
        Sale::where('id',$sale)->update(['void'=>True]);
        return redirect('sale/show');
    }


    public function credit_cash(){
        $customers =Customer::where('customer_id',$_POST['cus'])->get();

        foreach ($customers as $cus) {
         return array($cus->credit_sales,$cus->customer_name);
     }
    }
    //customer ledger 
    public function cashpaidledger($account_id,$cashpaid,$refrenceid,$transectiontype,$date,$datebit){
         
         //check if cashpaid agains chart of account is not empty
        if($cashpaid > 0){ 
        //initializing balance variable 
         if ($datebit == 1) {

        $this->assetledger($account_id,1,"assets",$cashpaid,null,$transectiontype,$refrenceid,$date);
         }
         // elseif ($datebit == 0) {
         //     $this->current_date_assetledger($account_id,1,"assets",$cashpaid,null,$transectiontype,$refrenceid,$date);
         // }
        }
    }
    
    //storing inventory ledger
    public function inventoryledger($account_id,$credit_ammount,$refrenceid,$date,$datebit){
      if ($datebit == 1) {
       $this->assetledger($account_id,1,"assets",null,$credit_ammount,2,$refrenceid,$date);
       }
       // elseif ($datebit == 0) {
       //   $this->current_date_assetledger($account_id,1,"assets",null,$credit_ammount,2,$refrenceid,$date);
       //  }
    }

    //storing credit sale ladger 
    public function credit_sale_ladger($account_id,$debit_ammount,$refrenceid,$transectiontype,$date,$datebit){
        if ($datebit == 1) {
        $this->assetledger($account_id,1,"assets",$debit_ammount,null,$transectiontype,$refrenceid,$date);
        }
       // elseif ($datebit == 0) {
       //  $this->current_date_assetledger($account_id,1,"assets",$debit_ammount,null,$transectiontype,$refrenceid,$date);
       // }
    }


    public function paymentrecieved(){
        $sales=Sale::all();
        $fy=Fiscalyear::orderby('id','desc')->first();
            if($fy != null){
            $fy=date('20y,m,d', strtotime($fy->fy.'-1 year'));
            }
            else{
                $fy='2017,12,5';
            }
        $chartofaccounts=DB::table('cprelations')->select('cprelations.*','chartofaccounts.account_type')->leftjoin('chartofaccounts','chartofaccounts.coa_id','cprelations.acc_id')->orderByRaw("FIELD(def ,1) DESC")->get();
        $suppliers=Supplier::all();
        //return $suppliers;
        $assets=Chartofaccount::where('coa_id','Not Like','%product_%')->where('coa_id','!=','padvance101')->where('coa_id','Not Like','%supplier_%')->where('account_type',1)->orwhere('account_type',5)->get();
        $employees=Employee::all();
        //all products from products table
        $products=Product::all();
        $customers=Customer::all();
        return view('sale.paymentrecieved',compact('sales','chartofaccounts','products','employees',
            'assets','suppliers','customers','fy'));
    }
    public function customer_invoices(Request $request){
        $sales=SALE::where('customer',$request->customer_id)->get();
        return $sales;
    }
    public function sale_invoice(Request $request){
        $sales=SALE::where('sales.id',$request->sale_invoice_number)->first();
        //echo "working";
        echo json_encode(array($sales->date,$sales->subtotal,$sales->cashpaid,$sales->duebalance,$sales->coa));
    }

    public function sale_products(Request $request){
        $saleproducts=Saleproduct::leftjoin('products','products.product_id','=','saleproducts.product')->where('inv_id',$request->sale_id)->get();
         return $saleproducts;
    }


    public function store_cashrecieved(Request $request)
    {
        //here validating empty fields
        $this->validate($request,
            ['customer'=>'required']);
        $transectiontype=9;
         //storing data in databas table sales
        $cashrecieved=new Cashrecieved;
        $cashrecieved->cr_customer=$request->customer;
        // $cashrecieved->invoice_id=$request->inv;
        $cashrecieved->cr_date=$request->date;
        // $cashrecieved->cr_subtotal=$request->total; 
        $cashrecieved->cr_cashpaid=$request->cash_paid;
        // $cashrecieved->cr_duebalance=$request->total_amount;
        $cashrecieved->cr_coa=$request->coa;
        $cashrecieved->void=false;
        $cashrecieved->user_id=Auth::id();
        //checking if cashrecieveds data saved successfully and proceed
        if($cashrecieved->save())
        {
            Sale::where('id',$request->inv)->update(['duebalance'=>$request->partyBalance]);
           
        //$reference id variable to refrence ledger entries
         $refrence_id=Cashrecieved::orderby('id','desc')->limit(1)->first();
          $this->cashrecievedcashpaidledger($request->coa,$request->cash_paid,$refrence_id,$transectiontype,$request->customer,$request->date,$request->date_bit);
         //if credit sale check box is checked
       $finalarray = array();
       $tempprice=0;
       $tempqty=0;
       $tempresult=0;
       $tempamount=0;
       $arr_productid = $request->product;
       $arr_productprice = $request->sprice;
       $arr_productqty = $request->qty;
       $arr_inlintotal=$request->inlinetotal;
       $count=count($arr_productid);
       $arr_flag = array();
       //creating flag element in array
       for ($i = 0; $i < count($arr_productid); $i++){
            $arr_flag[$i] = 0;
       }
       // for ($i = 0; $i < count($arr_productid); $i++){
       //          echo $arr_productid[$i] . "&nbsp;" . $arr_productprice[$i] . "&nbsp;" . $arr_productqty[$i]  . "&nbsp;" . $arr_flag[$i];
       //              echo "<br>";
       // }
       //              echo "Data Begins";
       //              echo "<br>";
       //looping through product arrays to sum up qty and price of same product_id
       for ($i = 0; $i < count($arr_productid); $i++){
        //temp id storing first itrations product id
            $tempid = $arr_productid[$i];
            //loop again to track same product id
            for($j = 0; $j < count($arr_productid); $j++){
                //checking if fileds are not empty to avoid store null data
                if($arr_productid[$j] != ""){
                    //checking if first itrations product id is equal to second itrations product id and flag is not equal to 1
                if($arr_productid[$j] == $tempid && $arr_flag[$j] != 1){
                    //summing up qty of same products
                    $tempqty += $arr_productqty[$j];
                    //summing up inline ammount of same products
                    $tempamount +=$arr_inlintotal[$i];
                     //getting price of each product
                    $tempprice = $arr_productprice[$j];

                    $arr_flag[$j] = 1;
                }
                }
            }
            if ($tempqty != 0){
                //checking if fileds are not empty to avoid store null data
                if($arr_productid[$i] !="" && $tempprice !="" && $tempqty !=""){
                    //add sale products
                    $Cashrecievedproduct=new Cashrecievedproduct;
                    $Cashrecievedproduct->cr_id=$refrence_id->id;
                    $Cashrecievedproduct->cr_inv_id=$request->inv;
                    $Cashrecievedproduct->cr_product=$arr_productid[$i];
                    $Cashrecievedproduct->cr_sale_price=$tempprice;
                    $Cashrecievedproduct->cr_qty=$tempqty;
                    $Cashrecievedproduct->cr_inlinetotal=$tempamount;
                    $Cashrecievedproduct->save();
                    $tempqty = 0;
                    $tempprice = 0;
                }
            }
       }
        $request->session()->flash('message.level', 'success');
        $request->session()->flash('message.content', 'New Sale Has Been Added');
        }
         return redirect('sale/payment');
    }


     //customer ledger 
    public function cashrecievedcashpaidledger($account_id,$cashpaid,$refrenceid,$transectiontype,$customer,$date,$datebit){
         //check if cashpaid agains chart of account is not empty
        if($cashpaid > 0){ 
            if($datebit == 1){ 
            $this->assetledger($account_id,1,"assets",$cashpaid,null,$transectiontype,$refrenceid,$date);
            $this->assetledger('customer_'.$customer,1,"assets",null,$cashpaid,$transectiontype,$refrenceid,$date);
            }
            // else if($datebit == 0){
            // $this->current_date_assetledger($account_id,1,"assets",$cashpaid,null,$transectiontype,$refrenceid,$date);
            // $this->current_date_assetledger('customer_'.$customer,1,"assets",null,$cashpaid,$transectiontype,$refrenceid,$date);
            // }
        }
    }


    public function sale_ledger($total,$refrenceid,$date,$datebit){

        $this->incomeledger(10101,4,"income",null,$total,2,$refrenceid,$date);
        // if($datebit == 1){
        // $this->incomeledger(10101,4,"income",null,$total,2,$refrenceid,$date);
        // }
        // else if($datebit == 0){
        // $this->current_date_incomeledger(10101,4,"income",null,$total,2,$refrenceid,$date);
        // }
    }

    public function cost_sale_ledger($total,$refrenceid,$date,$datebit){

        
        $this->expensledger(10102,5,"expense",$total,null,2,$refrenceid,$date);
        // if($datebit == 1){
        // $this->expensledger(10102,5,"expense",$total,null,2,$refrenceid,$date);
        // }
        // else if($datebit == 0){
        // $this->current_date_expensledger(10102,5,"expense",$total,null,2,$refrenceid,$date);
        // }
    }

    public function partybalance(Request $request){
     $sbal=Ledger::select('ledgers.*','chartofaccounts.account_type as actype')->leftjoin('chartofaccounts','chartofaccounts.coa_id','=','ledgers.account_id')->where('account_id',$request->customer)->orderby('date','desc')->first();
        if($sbal != null){
            echo json_encode(array($sbal->balance,$sbal->actype,$sbal->account_id));
        }
        else{
            $accdetails=Chartofaccount::where('coa_id',$request->customer)->first();
            echo json_encode(array("null",$accdetails->account_type,$accdetails->coa_id));
        }
        
    }
    
}
    