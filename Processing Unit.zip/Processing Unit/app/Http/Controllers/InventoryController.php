<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Inventory;
use App\Saleproduct;
use App\Bill_product;
use App\Product;
class InventoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    Public function __construct(){
        //check if user lgged in
        $this->middleware('auth');
    }

    //index function to show all inventories
    public function index()
    {
           $inventories=Inventory::leftjoin('products','products.product_id','=','inventories.inv_product_id')
           ->leftjoin('finalized_products','finalized_products.product_id','=','inventories.inv_by_product_id')
           ->leftjoin('productions','productions.product_id','=','inventories.inv_by_product_id')
           ->selectRaw('inventories.*,sum(inventories.inv_qty) as sum,products.product_description,finalized_products.name,count(inv_cost_price) as count_price ,sum(inv_cost_price) as sumprice ')  
           ->selectRaw('productions.*,productions.product_id=finalized_products.raw_id')
           ->groupBy('inv_product_id')->orderby('inventories.id','desc')->get();

           // $recordQty = Inventory::selectRaw('sum(inv_qty) as sumQty')->groupBy('inv_product_id')->get();

           // $recordAmount = Inventory::selectRaw('sum(inv_cost_price) as sumprice')->groupBy('inv_product_id')->get();
           
        // return $inventories;
         return view('inventory/view',compact('inventories'));
    }

    //returning inventories against single product
    public function single_product_inventory($product_id){
        $productname=Product::where('product_id',$product_id)->first();
        //return $purchaseproductqty;
        $inventories=Inventory::leftjoin('products','products.product_id','=','inventories.inv_product_id')->leftjoin('finalized_products','finalized_products.product_id','=','inventories.inv_by_product_id')->leftjoin('suppliers','suppliers.supplier_id','=','inventories.inv_supplier_id')->where('inv_product_id',$product_id)->orderby('inventories.id','desc')->get();
        return view('inventory/singleview',compact('inventories','productname'));
        // foreach ($inventories as $Inventory) {



        // }
        
    }

    
}
