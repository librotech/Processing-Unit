<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;
use DB;
use Auth;
use App\Chartofaccount;
use App\byproducts;
use App\production;
use App\Parent_production;
use App\FinalizedProduct;
use App\Cashrecieved;
use App\Inventory;
use Carbon\Carbon;
use App\ledger;

class ProductController extends Ledgerfunctions
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    Public function __construct(){
        $this->middleware('auth');
    }
    public function index()
    {
        $query=DB::raw('SELECT * From products LEFT JOIN users ON products.user_id = users.id');
        $products=DB::select($query);
        return view('product/view' , compact('products'));
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $products=DB::table('products')->orderBy('product_id', 'desc')->first();
        return view('product.add',compact('products'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $this->validate($request,
            ['txt_product_id'=>'required',
            'txt_product_description'=>'required',
            'txt_sale_price'=>'required',

            
        ]);
        $check_duplicate=Product::where('product_id',$request->txt_product_id)->first();
        if($check_duplicate !== null){
            $request->session()->flash('message.level', 'danger');
            $request->session()->flash('message.content', 'This Product  Already Available Please Try Changed Product Id');
            return redirect('product/add');
        }
        else{
           
                    $product=new Product;
                    $product->product_id=$request->txt_product_id;
                    $product->product_description=$request->txt_product_description.'_raw';
                    $product->sale_price=$request->txt_sale_price;
                    $product->cost_price=$request->txt_cost_price;
                    $product->weight=$request->txt_weight;
                    $product->user_id=Auth::id();

                    $product->save();

                     $this->product_chart_of_account('product_'.$request->txt_product_id,'product_'.$request->txt_product_description.'_raw','product_'.$request->txt_product_description.'_account');
                
                 }
            // $this->product_chart_of_account('product_'.$request->txt_product_id,'product_'.$request->txt_product_description.'_finished','product_'.$request->txt_product_description.'_account');
            $request->session()->flash('message.level', 'success');
            $request->session()->flash('message.content', 'New Product was successfully added!');
            
            
            $request->session()->flash('message.level', 'success');
            $request->session()->flash('message.content', 'New Product was successfully added!');
        
        
            return redirect('product/add');
        }
    


    public function production(){

        $products = Product::all();
        $auto_increment=DB::select("SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA ='rice' AND TABLE_NAME ='productions'");
        // $raw = Product::where('product_description' ,'Like', '%_raw')->get();
        // $product = Product::where('product_description' ,'NOT Like', '%_raw')->get();
        return view('product/production' , compact('products' ,'auto_increment'));


    }
    public function production_product(){

        $byproduct = DB::table('finalized_products')->where('raw_id',$_POST['product'])->get();
        // $product   = DB::table('finalized_products')->where('product_id' , $_POST['product'])->first();
        // return $byproduct;

         // echo json_encode(array($product->product_description,$product->bag_price,$product->product_id,$product1->product_description,$product1->bag_price,$products));
         echo json_encode(array($byproduct));
    }

    public function populate_product(){

        $product   = FinalizedProduct::where('product_id' , $_POST['by_id'])->get();
        // return $byproduct;
        foreach($product as $pro){

            return array($pro->name , $pro->cost_price , $pro->weight);
        }
         // echo json_encode(array($product->product_description,$product->bag_price,$product->product_id,$product1->product_description,$product1->bag_price,$products));
         // echo json_encode(array($product));
    }

    public function production_save(Request $request){

        $productPrice = 0;
        $productWeight = 0;
        $_costofsale  = 0;
        $transectiontype=2;

        $parent = new Parent_production;
        $parent->product_id  = $request->txt_product_id;
        $parent->qty  = $request->tweight;
        $parent->save();

        // $refrence_id=Cashrecieved::orderby('id','desc')->first();

        $refrence_id = $request->txt_inv_no;
        $date=date('Y-m-d');

        $this->assetledger('product_'. $request->txt_product_id,1,"assets",null,$request->pro_price*$request->bags,$transectiontype,$request->txt_product_id,$date);
        $this->update_inventory($request->txt_product_id,$request->tweight,$refrence_id,$request->total,$_costofsale,$request->date,$date);

        $record_id = Parent_production::orderby('id','desc')->first()->id; 
        // $date = Carbon::now()->toDateTimeString();

        $arr_by_product_id =  $request->txt_byproduct_id;
        $arr_by_product_id[] =  $request->txt_byproduct_id1;
        $arr_weight =  $request->np_weight;
        $arr_weight[] =  $request->np_weight1;
        $arr_price = $request->byprice;
        $arr_price[] = $request->byprice1;
        
        for($i =0; $i<count($arr_by_product_id); $i++){

        $production = new production;
        $production->record_id    =  $record_id;
        $production->product_id   =  $request->txt_product_id;
        $production->byproduct_id =  $arr_by_product_id[$i];
        $production->weight       =  $arr_weight[$i];
        $production->yeild        =  $request->yield;
        $production->cost_price   =  $arr_price[$i];
        $production->save();
         // $this->Addinventory($request->txt_product[$i],$request->txt_bill_no,$request->txt_supplier,$request->pricee[$i],$request->qtyy[$i],$request->txt_date);
        $productPrice += $arr_price[$i]*$arr_weight[$i];

        $this->assetledger('product_1'.$arr_by_product_id[$i],1,"assets" ,$arr_price[$i]*$arr_weight[$i],null,$transectiontype,$arr_by_product_id[$i],$date);
        $this->Addinventory($arr_by_product_id[$i],$arr_by_product_id[$i],$arr_by_product_id[$i],Auth::user()->id,$arr_price[$i],$arr_weight[$i],$date);
    }
        $total = ($request->pro_price*$request->bags)-($productPrice);
        if($total<0){
             $this->expensledger(10104,5,"expense",null,abs($total),2,$refrence_id,$date);
        }
        else{
              $this->expensledger(10104,5,"expense",$total,null,2,$refrence_id,$date);
        }
        $request->session()->flash('message.level', 'success');
        $request->session()->flash('message.content', 'New Production was successfully added!');
        
        return redirect('product/production');
        
    }

    public function show_production(){

        $products  =  production::select('productions.*' , 'products.product_id' , 'products.product_description')->leftjoin('products','products.product_id' , 'productions.product_id')->groupby('productions.record_id')->get();

        return view('product/view_production' , compact('products'));
    }

    public function price(Request $request){

        $product_price = Product::select('sale_price')->where('product_id',$request->product)->first();

    
        return $product_price->sale_price;
    }

    public function show_single_production($single){

        $byproducts  =  production::select('productions.*' , 'finalized_products.product_id' , 'finalized_products.name')->leftjoin('finalized_products' ,'finalized_products.product_id', 'productions.byproduct_id')->where('productions.record_id' ,$single)->get();

        return view('product/view_single_production' , compact('byproducts'));
    }

    public function product_chart_of_account($account_id,$account_title,$account_description){
        $chartofaccount=new Chartofaccount();
        $chartofaccount->coa_id=$account_id;
        $chartofaccount->coa_title=$account_title;
        $chartofaccount->account_type=1;
        $chartofaccount->coa_description=$account_description;
        $chartofaccount->user_id=Auth::id();
        if($chartofaccount->save()){
            app('App\Http\Controllers\ChartofaccountController')->log_chartofaccount($account_id,$account_title,$account_description,1);
        }
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show($product_id)
    {
        $product =DB::table('products')->where('product_id',$product_id)->get();
        $byproduct = DB::table('finalized_products')->where('product_id' , $product_id)->get();
        // return $product;
        return view('product/edit',['products'=>$product , 'byproduct'=>$byproduct]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $this->validate($request,
            ['txt_product_id'=>'required',
            'txt_product_description'=>'required',
            'txt_sale_price'=>'required',
        ]);
        
        $updateproduct = DB::table('products')->where('product_id',$request->txt_product_id)->update(['product_id'=>$request->txt_product_id , 'product_description' => $request->txt_product_description , 'sale_price'=>$request->txt_sale_price , 'cost_price' => $request->txt_cost_price , 'weight'=>$request->txt_weight]);


        for($i = 0;$i < count($request->txt_product_by_id);$i++){

         $update=DB::table('finalized_products')->where('id', $request->rec_id_by[$i])
            ->update(['product_id'=>$request->txt_product_by_id[$i],'name' => $request->txt_product_by_name[$i],'sale_price'=>$request->txt_product_by_price[$i] , 'weight'=>$request->txt_weight[$i]]);
         
      
        }
        $request->session()->flash('message.level', 'success');
            $request->session()->flash('message.content', 'Product Details successfully Updated!');
        return redirect('product/show/'.$request->txt_rec_id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy($product)
    {
        DB::table('products')->where('product_id',$product)->delete();
        return redirect('product/show');
    }

    public function allproducts(){
        $products=Product::all();
        foreach ($products as $product) {
            echo "<option value=".$product->product_id.">".$product->product_description."</option>";
        }
        echo '<option value="add_product" class="btn btn-info"></option>';
    }
    public function update_inventory($product_id,$qty,$refrence_id,$total, &$_costofsale,$date,$datebit){

         // echo 'product_id&nbsp'.$product_id."&nbsp  Quantity&nbsp".$qty."<br>";
        //updated at date formate
         $updated_at=date('Y-m-d H:i:s');
         $fin=0;
         $costofsale=0;
         $fin2=0;
         $input_qty=$qty;
         $res_price=0;
         $originalqty=0;
         $wholeqty =Inventory::where('inv_product_id',$product_id)->sum('inv_qty');
         $dbcp=0;
         //getting inventories
         $inventories=Inventory::where('inv_product_id',$product_id)->get();
         foreach ($inventories as $inventory) {
            //storing inventory id in $inventory_id
             $inventory_id=$inventory->id;
            //checking if sold item quantot is less then qty available in inventory agaainst that product
           if($inventory->inv_qty > $qty && $qty != 0 || $inventory->inv_qty == $qty && $qty != 0){
                //updated qty
                $final_qty=$inventory->inv_qty-$qty;
                //updated inventory of particular product with final_qty in below query
                $dbcp=$inventory->inv_cost_price;
                DB::table('inventories')->where('id',$inventory->id)->update(['inv_qty'=>$final_qty,'updated_at'=>$updated_at]);

                //empting sold product qty
                $qty=$qty-$qty;
               
            }
             //checking if sold item quantot is greater then qty available in inventory agaainst that product
            elseif($inventory->inv_qty < $qty) {
                //updated qty
                  $final_qty=$inventory->inv_qty-$inventory->inv_qty;
                  
                  //updated inventory of particular product with $final_qty in below query
                 DB::table('inventories')->where('id',$inventory->id)->update(['inv_qty'=>$final_qty,'updated_at'=>$updated_at]);

                 //summing up qty
                $originalqty +=$inventory->inv_qty;
                //sutracting sold qty from available qty
                $qty=$qty-$inventory->inv_qty;
                //getting last product ledger
                
               
                    $dbcp=$inventory->inv_cost_price;
                   //calculating resulting price
                  $res_price += $inventory->inv_qty*$inventory->inv_cost_price;
            }
            
            
           //echo 'price ='.$fin."<br>";
                
              }
              //echo $wholeqty."<br>";
           if($input_qty > $wholeqty){
            $minus_quantity=$wholeqty-$input_qty;
            $last_record=DB::table('inventories')->where('inv_product_id',$product_id)->orderby('id', 'desc')->first();
                //updated inventory of particular product with $minus_quantity in below query
               DB::table('inventories')->where('id',$last_record->id)->update(['inv_qty'=>$minus_quantity,'updated_at'=>$updated_at]);
            }
            
        // //calculating final price
        $fin =$res_price+($input_qty-$originalqty)*$dbcp;
            $_costofsale +=$fin;
        //   //echo $fin;
        // //storing inventory ledger by calling inventoryledger function
        // $this->inventoryledger("product_".$product_id,$fin,$refrence_id,$date,$datebit);
        
    }
      public function Addinventory($pid,$bpid,$biil_id,$sup_id,$cost_price,$qty,$date){
        $inventory=new Inventory;
        $inventory->inv_product_id=$pid;
        $inventory->inv_by_product_id = $bpid;
        $inventory->inv_bill_id=$biil_id;
        $inventory->inv_supplier_id=$sup_id;
        $inventory->inv_cost_price=$cost_price;
        $inventory->inv_qty=$qty;
        $inventory->inv_purchased_qty=$qty;
        $inventory->inv_bill_date=$date;
        $inventory->status = 1;
        $inventory->save();
    }
}
