<?php

namespace App\Http\Controllers;

use App\FinalizedProduct;
use Illuminate\Http\Request;
use DB;
use Auth;
use App\Product;
use App\Chartofaccount;

class FinalizedProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
      Public function __construct(){
        $this->middleware('auth');
    }
    public function index()
    {
        $products = FinalizedProduct::select('finalized_products.*' , 'products.product_description')->leftjoin('products' , 'products.product_id' , 'finalized_products.raw_id')->get();

        return view('finalized_product/view' , compact('products'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $products = Product::all();
        // return $products;
        return view('finalized_product.add' , compact('products'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
          
        $check_duplicate=FinalizedProduct::where('product_id',$request->txt_product_id1)->first();
        if($check_duplicate !== null){

            $request->session()->flash('message.level', 'danger');
            $request->session()->flash('message.content', 'This Product  Already Available Please Try Changed Product Id');
            return redirect('finalized_product/add');
        }
       
                $product=new FinalizedProduct;
                $product->product_id=$request->txt_product_id1;
                $product->raw_id = $request->txt_product;
                $product->name=$request->txt_product_description1;
                $product->sale_price=$request->txt_sale_price1;
                $product->cost_price=$request->txt_cost_price1;
                $product->weight=$request->txt_weight1;
                $this->product_chart_of_account('product_1'.$request->txt_product_id1,'product_'.$request->txt_product_description1,'product_'.$request->txt_product_description1.'_account');

                if($product->save()){

                   

                    for($i=0; $i < count($request->txt_product_id); $i++){

                        $check_duplicate=FinalizedProduct::where('product_id',$request->txt_product_id[$i])->first();
                            if($check_duplicate !== null){

                                $request->session()->flash('message.level', 'danger');
                                $request->session()->flash('message.content', 'This Product  Already Available Please Try Changed Product Id');
                                return redirect('finalized_product/add');
                                 }
                               
                        $product=new FinalizedProduct;
                        $product->product_id=$request->txt_product_id[$i];
                        $product->raw_id = $request->txt_product;
                        
                        $product->name=$request->txt_product_description[$i];
                        $product->sale_price=$request->txt_sale_price[$i];
                        $product->cost_price=$request->txt_cost_price[$i];
                        $product->weight=$request->txt_weight[$i];
                        $product->save();

                         $this->product_chart_of_account('product_1'.$request->txt_product_id[$i],'product_'.$request->txt_product_description[$i],'product_'.$request->txt_product_description[$i].'_account');
                    
                     }
                 }
                  $request->session()->flash('message.level', 'success');
                    $request->session()->flash('message.content', 'New Product was successfully added!');
            
        
            return redirect('finalized_product/add');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\FinalizedProduct  $finalizedProduct
     * @return \Illuminate\Http\Response
     */
    public function show($product_id)
    {
        $products = DB::table('finalized_products')->where('product_id' , $product_id)->get();

        return view('finalized_product/edit' , compact('products'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\FinalizedProduct  $finalizedProduct
     * @return \Illuminate\Http\Response
     */
    public function edit(FinalizedProduct $finalizedProduct)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\FinalizedProduct  $finalizedProduct
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
       $this->validate($request,
            ['txt_product_id'=>'required',
            'txt_product_name'=>'required',
            'txt_sale_price'=>'required',
        ]);

        $update  = DB::table('finalized_products')
        ->where('product_id' , $request->txt_product_id)
        ->update([
            'product_id' => $request->txt_product_id,
            'name'       => $request->txt_product_name,
            'sale_price' => $request->txt_sale_price,
            'cost_price' => $request->txt_cost_price]);
        
         if ($update) {
            $request->session()->flash('message.level', 'success');
            $request->session()->flash('message.content', 'Product Details successfully Updated!');
        }
        return redirect('finalized_product/show');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\FinalizedProduct  $finalizedProduct
     * @return \Illuminate\Http\Response
     */
    public function destroy($product_id)
    {
        DB::table('finalized_products')->where('product_id' , $product_id)->delete();
        return redirect('finalized_product/show');
    }

    public function product_chart_of_account($account_id,$account_title,$account_description){
        $chartofaccount=new Chartofaccount();
        $chartofaccount->coa_id=$account_id;
        $chartofaccount->coa_title=$account_title;
        $chartofaccount->account_type=1;
        $chartofaccount->coa_description=$account_description;
        $chartofaccount->user_id=Auth::id();
        if($chartofaccount->save()){
            app('App\Http\Controllers\ChartofaccountController')->log_chartofaccount($account_id,$account_title,$account_description,1);
        }
    }
}
