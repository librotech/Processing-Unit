@extends('layouts.master')
@section('title', 'Accounts System-Design')
@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    <li class="nav-item">
      <a class="nav-link"  href="{{ url('/home') }}">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link active">Add New Design</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="{{ url('Design/view') }}">All Designs</a>
    </li>
</ul>
<br>
<div class="col-md-12">
<h3>Create A New Design</h3>
<hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
    @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
    @endif
    <form class="form-horizontal" method="POST" action="{{ url('Design/store') }}">
    {{ csrf_field() }}
        <div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <label for="dc">Design Code</label>
                <input id="name" type="text" class="form-control" name="desinecode" required autofocus>
            </div>
        </div>
        <div class="col-md-3"></div>
        <div class="col-md-3"></div>
         <div class="col-md-3">
            <div class="form-group">
                <label for="dc">Date</label>
                <input value="{{ date('20y:m:d') }}" class="form-control" readonly="">
            </div>
        </div>
        <hr>
        <table class="table table-hover order-list table-responsive">
                <thead>
                <tr>
                    <th>Description</th>
                    <th>No of Stitches</th>
                    <th colspan="2">Machine Type</th>
                    
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>
                    <input type="text" required="required"  name="description[]" readonly  class="form-control"  autocomplete="no" value="Front">
                    </td>
                    
                    <td><input type="number"  onkeypress="return isNumberKey(event,this)"  min="0" id="no_stitch"   name="no_stitch[]" class="form-control no_stitch" placeholder="No Of Stich"></td>
                    <td>
                        <input type="radio"  value="2.77" checked name="mtype[0] m_type0" data-id="0" class="form-control first">330m <hr>
                        <div id="multiradio_0">
                          <input type="radio" value="0" checked  name="three30[0] three30_0">&nbsp Multilevel<br>
                          <input type="radio" value="1"  name="three30[0] three30_0">&nbsp Laser<br>
                          <input type="radio" value="2"  name="three30[0] three30_0">&nbsp None<br> 
                        <div>
                    </td>
                    <td>
                        <input type="radio" data-id="0" name="mtype[0] m_type0" value="2.032" class="form-control second">450m 
                    </td>

                    
                </tr>
                <tr>
                    <td>
                    <input type="text" required="required"  name="description[]" readonly class="form-control"  autocomplete="no" value="Gala">
                    </td>
                    
                    <td><input type="number"  onkeypress="return isNumberKey(event,this)" min="0" id="no_stitch"  name="no_stitch[]" class="form-control no_stitch" placeholder="No Of Stich"></td>
                    <td>
                        <input type="radio" data-id="1"  value="2.77" checked name="mtype[1] m_type1" class="form-control first">330m <hr>
                        <div id="multiradio_1">
                          <input type="radio" value="0" checked  name="three30[1] three30_1">&nbsp Multilevel<br>
                          <input type="radio" value="1"   name="three30[1] three30_1">&nbsp Laser<br>
                          <input type="radio" value="3"   name="three30[1] three30_1">&nbsp None<br> 
                        <div>
                    </td>
                    <td>
                        <input type="radio" data-id="1"  name="mtype[1] m_type1" value="2.032" class="form-control second">450m 
                    </td>
                    
                </tr>
                <tr>
                    <td>
                    <input type="text" required="required"  name="description[]" readonly class="form-control"  autocomplete="no" value="Lais">
                    </td>
                    
                    <td><input type="number"  onkeypress="return isNumberKey(event,this)"  min="0" id="no_stitch"  name="no_stitch[]" class="form-control no_stitch" placeholder="No Of Stich"></td>
                    <td>
                        <input type="radio" data-id="2" value="2.77" checked name="mtype[2] m_type2" class="form-control first">330m <hr>
                        <div id="multiradio_2">
                          <input type="radio" value="0" checked name="three30[2] three30_2">&nbsp Multilevel<br>
                          <input type="radio" value="1"  name="three30[2] three30_2">&nbsp Laser<br>
                          <input type="radio" value="3"   name="three30[2] three30_2">&nbsp None<br>
                        <div>
                    </td>
                    <td>
                        <input type="radio" data-id="2"   name="mtype[2] m_type2" value="2.032" class="form-control second">450m 
                    </td>
                    
                </tr>
                <tr>
                    <td>
                    <input type="text" required="required"  name="description[]" readonly class="form-control"  autocomplete="no" value="Chest">
                    </td>
                    
                    <td><input type="number"  onkeypress="return isNumberKey(event,this)" min="0" id="no_stitch"  name="no_stitch[]" class="form-control no_stitch" placeholder="No Of Stich"></td>
                    <td>
                        <input type="radio" data-id="3" value="2.77" checked name="mtype[3] m_type3" class="form-control first">330m <hr>

                         <div id="multiradio_3">
                          <input type="radio" value="0"  checked name="three30[3] three30_3">&nbsp Multilevel<br>
                          <input type="radio" value="1"  name="three30[3] three30_3">&nbsp Laser<br>
                          <input type="radio" value="3"   name="three30[3] three30_3">&nbsp None<br>
                        <div>
                    </td>
                    <td>
                        <input type="radio" data-id="3"  name="mtype[3] m_type3" value="2.032" class="form-control second">450m 
                    </td>
                    
                </tr>
                <tr>
                    <td>
                    <input type="text" required="required"  name="description[]" readonly class="form-control"  autocomplete="no" value="Dopata">
                    </td>
                    
                    <td><input type="number"  onkeypress="return isNumberKey(event,this)"  min="0" id="no_stitch"  name="no_stitch[]" class="form-control no_stitch" placeholder="No Of Stich"></td>
                    <td>
                        <input type="radio" data-id="4" value="2.77" checked name="mtype[4] m_type4" class="form-control first">330m <hr>
                        <div id="multiradio_4">
                          <input type="radio" value="0" checked name="three30[4] three30_4">&nbsp Multilevel<br>
                          <input type="radio" value="1"  name="three30[4] three30_4">&nbsp Laser<br>
                          <input type="radio" value="3"   name="three30[4] three30_4">&nbsp None<br>
                        <div>
                    </td>
                    <td>
                        <input type="radio" data-id="4"  name="mtype[4] m_type4" value="2.032" class="form-control second">450m 
                    </td>
                    
                </tr>
                 <tr>
                    <td>
                    <input type="text" required="required"  name="description[]" readonly class="form-control"  autocomplete="no" value="kali">
                    </td>
                    
                    <td><input type="number"  onkeypress="return isNumberKey(event,this)"  min="0" id="no_stitch"  name="no_stitch[]" class="form-control no_stitch" placeholder="No Of Stich"></td>
                    <td>
                        <input type="radio" data-id="5" value="2.77" checked name="mtype[5] m_type5" class="form-control first">330m <hr>
                        <div id="multiradio_5">
                          <input type="radio" value="0" checked name="three30[5] three30_5">&nbsp Multilevel<br>
                          <input type="radio" value="1"  name="three30[5] three30_5">&nbsp Laser<br>
                          <input type="radio" value="3"   name="three30[5] three30_5">&nbsp None<br>
                        <div>
                    </td>
                    <td>
                        <input type="radio" data-id="5" name="mtype[5] m_type5" value="2.032" class="form-control second">450m 
                    </td>
                    
                </tr>
            </tbody>

        </table>
        <hr>
        <div class="col-md-3">
            <div class="form-group">
                <button type="submit" class="btn btn-success" style="margin-top:33px;">
                    Create Design
                </button>
            </div>
        </div>
     </form>
  </div>
</div>
<script type="text/javascript">
    $(document).on('click','.first',function(){
        var data_id = $(this).attr('data-id');
        var checked = $(this).attr('checked')
        $('#multiradio_'+data_id).css('display','block');
    });

    $(document).on('click','.second',function(){
        var data_id = $(this).attr('data-id');
        var checked = $(this).attr('checked')
        $('#multiradio_'+data_id).css('display','none');
    });
</script>
@endsection
