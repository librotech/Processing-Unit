
			<div class="nav-side-menu">
		    <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
		  
		        <div class="menu-list">
		  
		            <ul id="menu-content" class="menu-content collapse out">
		                <li>
		                  <a  href="{{ url('/home') }}">
		                  <i class="fa fa-dashboard fa-lg"></i> Dashboard
		                  </a>
		                </li>

		                <li  data-toggle="collapse" data-target="#products" class="collapsed active">
		                  <a href="#"><i class="fa fa-gift fa-lg"></i> Sales<span class="arrow"></span></a>
		                </li>
		                <ul class="sub-menu collapse" id="products">
		                    <li class="active"><a href="{{ url('sale/add') }}">Add Sale</a></li>
		                    <li><a href="{{ url('sale/payment') }}">Recieve Cash</a></li>
		                    <li><a  href="{{ url('creditnotes/add') }}">Return Sales</a></li>
		                </ul>
		                <li>
		                  <a href="{{ url('expense/add') }}">
		                  <i class="fa fa-user fa-lg"></i> Expense
		                  </a>
		                </li>
		                <li  data-toggle="collapse" data-target="#purchase" class="collapsed active">
		                  <a href="#"><i class="fa fa-gift fa-lg"></i> Purchase<span class="arrow"></span></a>
		                </li>
		                <ul class="sub-menu collapse" id="purchase">
		                    <li class="active"><a href="{{ url('purchase/add') }}">Add Purchase</a></li>
		                    <li><a href="{{ url('purchase/payment') }}">Pay Cash</a></li>
		                    <li><a  href="{{ url('debitnotes/add') }} ">Return Inventory</a></li>
		                </ul>

		                <li>
		                  <a href="{{ url('product/production') }}">
		                  <i class="fa fa-user fa-lg"></i> Production
		                  </a>
		                </li>
		                <li>
		                  <a href="{{ url('journal/add') }}">
		                  <i class="fa fa-user fa-lg"></i> Journal Entries
		                  </a>
		                </li>
		                <li>
		                  <a href="{{ url('coa/show') }}">
		                  <i class="fa fa-user fa-lg"></i> Chart Of Accounts
		                  </a>
		                </li>


		                <li data-toggle="collapse" data-target="#service" class="collapsed">
		                  <a href="#"><i class="fa fa-globe fa-lg"></i> Reports <span class="arrow"></span></a>
		                </li>  
		                <ul class="sub-menu collapse" id="service">
		                  <li><a href="{{ url('dailycashsales') }}">Cash Sales Reports</a></li>
    	<li><a href="{{ url('dailyexpenses') }}">Expense Reports</a></li>
    	<li><a href="{{ url('profitandlossreport') }}">Profit And Loss Report</a></li>
    	<li><a href="{{ url('balancesheetreport') }}">Balance Sheet Report</a></li>
    	<li><a href="{{ url('trialbalance') }}">Trial Balance Report</a></li>
    	<li><a href="{{ url('ledger/show') }}">Ledger Report</a></li>
		                </ul>


		                <li data-toggle="collapse" data-target="#new" class="collapsed">
		                  <a href="#"><i class="fa fa-car fa-lg"></i> New <span class="arrow"></span></a>
		                </li>
		                <ul class="sub-menu collapse" id="new">
		                  <li>New New 1</li>
		                  <li>New New 2</li>
		                  <li>New New 3</li>
		                </ul>
		                <li>
		                <a href="{{ url('cprelation/show') }}">
		                <i class="fa fa-users fa-lg"></i>Cash Paid Relation
		            	</a>
		            	</li>
		                <li>
		                  <a href="{{ url('fundstranser/add') }}">
		                  <i class="fa fa-users fa-lg"></i> Funds Transfer
		                  </a>
		                </li>
		                <li>
		                  <a href="{{ url('settings') }}">
		                  <i class="fa fa-users fa-lg"></i> Settings
		                  </a>
		                </li>
		                <li>
		                  <a  href="{{ url('user/view') }} ">
		                  <i class="fa fa-users fa-lg"></i> Users
		                  </a>
		                </li>
		            </ul>
		     </div>
		 </div>
			