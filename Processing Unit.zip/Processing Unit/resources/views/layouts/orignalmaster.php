<div class="card" style="border:none;margin-left:-15px;">
				<div class="card-header"><i class="fas fa-tachometer-alt" style="color:#EAEEF3;"></i>&nbsp<a  href="{{ url('/home') }}">Dashboard</a></div>
				<div class="card-header"><i class="fas fa-shopping-cart" style="color:#EAEEF3;"></i>&nbsp<a href="{{ url('purchase/add') }}">Purchase</a></div>

				<div class="card-header"><i class="fas fa-hand-holding-usd" style="color:#EAEEF3;"></i>&nbsp <a href="{{ url('purchase/payment') }}">Cash Paid</a></div>
				<div class="card-header"><i class="fas fa-donate" style="color:#EAEEF3;"></i>&nbsp<a href="{{ url('expense/add') }}">Expense</a></div>
				<div class="card-header"><i class="fas fa-chart-bar" style="color:#EAEEF3;"></i>&nbsp<a href="{{ url('coa/show') }}">Chart Of Account</a></div>				
				<div class="card-header"><i class="fas fa-hand-holding-usd" style="color:#EAEEF3;"></i>&nbsp <a href="{{ url('sale/add') }}">Sales</a></div>
				<div class="card-header"><i class="fas fa-hand-holding-usd" style="color:#EAEEF3;"></i>&nbsp <a href="{{ url('sale/payment') }}">Cash Recieved</a></div>
				<div class="card-header"><i class="fas fa-calculator" style="color:#EAEEF3;"></i>&nbsp<a href="{{ url('journal/add') }}">Journal Entries</a></div>
				<div class="card-header"><i class="fas fa-mercury" style="color:#EAEEF3;"></i>&nbsp<a href="{{ url('cprelation/show') }}">Cash Paid Relation</a></div>
				<div class="card-header"><i class="fas fa-exchange-alt" style="color:#EAEEF3;"></i>&nbsp<a href="{{ url('fundstranser/add') }}">Funds Transfer</a></div>
				<div class="card-header"><i class="fas fa-credit-card" style="color:#EAEEF3;"></i>&nbsp<a  href="{{ url('depriciate') }} ">Depriciate Fixed Asset</a></div>
				<div class="card-header"><i class="fas fa-credit-card" style="color:#EAEEF3;"></i>&nbsp<a  href="{{ url('creditnotes/add') }}">Credit Notes</a></div>
				<div class="card-header"><i class="fas fa-credit-card" style="color:#EAEEF3;"></i>&nbsp<a  href="{{ url('debitnotes/add') }} ">Debit Notes</a></div>
				<div class="card-header"><i class="fas fa-file" style="color:#EAEEF3;"></i>&nbsp<a  href="{{ url('report/view') }} ">Reports</a></div>
				<div class="card-header"><i class="fas fa-users" style="color:#EAEEF3;"></i>&nbsp<a  href="{{ url('user/view') }} ">Users</a></div>
				<div class="card-header"><i class="fas fa-wrench" style="color:#EAEEF3;"></i>&nbsp<a href="{{ url('settings') }}">Settings</a></div>
				
			</div>