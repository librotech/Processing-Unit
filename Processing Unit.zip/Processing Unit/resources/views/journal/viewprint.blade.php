@extends('layouts.master')

@section('title', 'Accounts System-All Sale')

@section('content')
<style>
@page { size: auto;  margin: 0mm; }
</style>
<a href="{{ url('journal/show') }}" class="btn btn-info" style="float:right;">view Journal Entery</a>
 <div id="printableArea">
    <h3>Journal Enteries</h3> 
    <hr>
        @foreach($journalentries as $journalentry)
         <b>Journal No</b><p>{{ $journalentry->id }}</p>
         <b>Dated</b><p>{{ $journalentry->date }}</p>
        @endforeach
	<table class="table table-hover" >
    	<tr>
    		<th>sr.num</th>
    		<th>Account Id</th>
    		<th>Account Name</th>
    		<th>Account Type</th>
            <th>Description</th>
    		<th>Debit</th>
            <th>Credit</th>
    	</tr>
        @foreach($subjournalentries as $subjournalentrie)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $subjournalentrie->account_id }}</td>
                <td>{{ $subjournalentrie->coa_title }}</td>
                <td>{{ $subjournalentrie->account_type }}</td>
                <td>{{ $subjournalentrie->description }}</td>
                <td>{{ $subjournalentrie->debit }}</td>
                <td>{{ $subjournalentrie->credit }}</td>
            </tr>
            
        @endforeach
    </table>
    </div>
    <input type="button" onclick="printDiv('printableArea')" value="print this report" class="btn btn-info" />
@stop
<script>
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
</script>
