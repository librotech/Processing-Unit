@extends('layouts.master')

@section('title', 'Accounts System-Journal Enteries')

@section('content')
    <h3>Journal Entries</h3>
    <!-- <a href="{{ url('journal/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Journal Entries</a> -->
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form  id="myForm" method="post">

        <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label>Journal No</label>
                <input type="number" name="txt_inv_no" value="{{ $journalentries->id }}" class="form-control" readonly="readonly">
                
            </div>
            
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label>Date</label>
                <input type="text" readonly="readonly" value="{{  $journalentries->date }}" name="txt_date" class="form-control">
            </div>
        </div>
        </div>
        <table class="table table-hover order-list">
                <thead>
                <tr>
                    <th>Account id</th>
                    <th>Account Name</th>
                    <th>Account Type</th>
                    <th>Description</th>
                    <th>Debit</th>
                    <th>Credit</th>
                </tr>
                </thead>
                <tbody>
                @foreach($subjournalentries as $subjournalentry)
                <tr>
                 <td>
                    <input type="hidden" name="rec_id[]" value="{{ $subjournalentry->id }}">
                    <input type="text" data-id="{{ $loop->iteration }}" value="{{ $subjournalentry->account_id }}" name="coa_id[]" class="form-control coa_id" placeholder="Chart of Account id" list="coas">
                    </td>
                    <td><input type="text" value="{{ $subjournalentry->coa_title }}" readonly="readonly" name="coa_name" class="form-control coa_name{{ $loop->iteration }}" placeholder="Account Name"></td>

                    <td><input type="text"  readonly="readonly" value="<?php if($subjournalentry->account_type == 1){
                        echo "assets";}elseif($subjournalentry->account_type == 2){ echo"Liabilities";}elseif($subjournalentry->account_type == 3){ echo"capital"; }elseif($subjournalentry->account_type == 4){ echo"Income"; }elseif($subjournalentry->account_type == 5){ echo"expencse"; }?>"  name="coa_type" class="form-control coa_type{{ $loop->iteration }}" placeholder="Account Type"></td>

                    <td><input type="text" value="{{ $subjournalentry->description }}"  name="description[]" class="form-control" placeholder="description"></td>
                    <td><input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" value="{{ $subjournalentry->debit }}" <?php if($subjournalentry->debit == null){ echo "readonly";} ?> name="debit[]" class="form-control debit debit{{ $loop->iteration }}" data-id="{{ $loop->iteration }}"placeholder="Debit Amount"></td>
                    <td><input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" value="{{ $subjournalentry->credit }}" <?php if($subjournalentry->credit == null){ echo "readonly";} ?>  name="credit[]" data-id="{{ $loop->iteration }}" class="form-control credit credit{{ $loop->iteration }}" placeholder="Credit Amount"></td>
                    
                    <!--<td><input type="button" id="addrow" value="Add More" class="btn btn-success"></td>-->

                </tr>
                @endforeach
            </tbody>

        </table>
        <div class="row">
             <div class="col-md-8"></div>
            <div class="col-md-4"></button></div>
        </div>
        {{ csrf_field() }}
    </form>
@stop