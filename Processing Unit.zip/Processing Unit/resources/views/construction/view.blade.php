@extends('layouts.master')

@section('title', 'Accounts System-Project')

@section('content')
<ul class="nav nav-tabs">
 <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >View Projects</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('project/add') }}">Add New Project</a>
  </li>
  
</ul><br>
    <h3>All Projects</h3> <a href="{{ url('project/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Add New Project</a>
    <hr>
    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
           <th>SNo.</th>
            <th>project Id</th>
            <th>project Name</th>
            <th>Employee</th>
            <th>Date</th>
            <th>Total</th>
            <th>Date</th>
            <th>Delete</th>
            <th>Edit</th>
        </tr>
        </thead>
        <tbody>
            

        @foreach($projects as $project)
            
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $project->id }}</td>
                <td>{{ $project->projectname }}</td>
                <td>{{ $project->employee_id }}</td>
                <td>{{ $project->name }}</td>
                <td>{{ $project->total }}</td>
                <td>{{ $project->created_at }}</td>
                <td><a href="{{ url('project/delete/'.$project->id) }}" class="btn btn-danger btn-sm" onclick="return confirm(' you want to delete?');">Delete</a></td>
                <td><a href="{{ url('project/show/'.$project->id)}}" class="btn btn-success btn-sm">Edit</a></td>
            </tr>
            
        @endforeach
    </tbody>
    <tfoot>
            <tr>
             <th>SNo.</th>
            <th>project Id</th>
            <th>project Name</th>
            <th>Employee</th>
            <th>Date</th>
            <th>Total</th>
            <th>Date</th>
            <th>Delete</th>
            <th>Edit</th>
            </tr>
        </tfoot>
    </table> 
   

    
@stop
