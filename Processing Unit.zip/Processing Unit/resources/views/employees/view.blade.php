@extends('layouts.master')

@section('title', 'Accounts System-Employee')

@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >View Employees</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('employee/add') }}">Add New Employee</a>
  </li>
  
</ul><br>
    <h3>All employees</h3> <a href="{{ url('employee/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Add New employee</a>
    <!-- <hr>
    <form method="post" action="{{ url('updateshift') }}">
      {{ csrf_field() }}  
    <button class="btn btn-danger">Invert Employees Shifts</button>
    </form> -->
    <hr />
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            
            <th>Employee Id</th>
            <th>Employee Name</th>
            <th>Salary</th>
            <th>Available</th>
            <!-- <th>Shift</th> -->
            <th>Date</th>
            <th>Edit</th>
            @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
        </tr>
        </thead>
        <tbody>
            

        @foreach($employees as $employee)
            <tr>
                <td>{{ $employee->id }}</td>
                <td>{{ $employee->name }}</td>
                <td>{{ $employee->salary }}</td>
                @if($employee->available)
                <td>Available</td>
                @else
                <td>Unavailable</td>
                @endif
            <!--     <td><div class="form-group">
                    <select id="role" data-id="{{ $employee->id }}" class="form-control shift" name="shift" required>
                    <option value="{{ $employee->shift }}">{{ $employee->shift }}</option>    
                    <option value="">Select</option>
                        <option value="day">day</option>
                        <option value="night">night</option>
                    </select>
                </div></td> -->
                <td>{{ $employee->created_at }}</td>
                <td><a href="{{ url('employee/show/'.$employee->id)}}" class="btn btn-success btn-sm">Edit</a></td>
                @if(Auth::user()->role == 1)
                <td><a href="{{ url('employee/delete/'.$employee->id) }}" class="btn btn-danger btn-sm" onclick="return confirm(' you want to delete?');">Delete</a></td>
                @endif
            </tr>
            
        @endforeach
    </tbody>
    <tfoot>
            <tr>
            
            <th>Employee Id</th>
            <th>Employee Name</th>
            <th>Salary</th>
            <th>Available</th>
            <!-- <th>Shift</th> -->
            <th>Date</th>
            <th>Edit</th>
            @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
            </tr>
        </tfoot>
    </table>

    <script>
      $(document).on('change','.shift',function(){
        var employee_id = $(this).attr('data-id');
        var _token = $('input[name="_token"]').val();
         $.ajax({
          type: 'POST',
          url: '{{ url("updatesingleshift") }}',
          data: {shift:$(this).val(),empid:employee_id,_token:_token}, // here $(this) refers to the ajax object not form
          success: function(data) {
              alert('Shift Changed');
          },
        });
      });
    </script>
@stop
