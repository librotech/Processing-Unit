@extends('layouts.master')
@section('title', 'Accounts System-Stitching Unit')
@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link" href="{{ url()->previous() }}">Back</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">Stiches Form</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('employees/editstitchform') }}">Update Employee Stitches</a>
  </li>

</ul>
<br>
<div class="col-md-12">
  <h3>Add Stitches</h3><a href="{{ url('employees/editstitchform') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Update Employees Stitch</a>
  <hr>
  @if(count($errors) > 0)
  @foreach($errors->all() as $error)
  <p class="alert alert-danger">{{ $error }}</p>
  @endforeach
  @endif
  @if(session()->has('message.level'))
  <div class="alert alert-{{ session('message.level') }}">
    {!! session('message.content') !!}
  </div>
  @endif
  <form class="form-horizontal" method="POST" action="{{ url('employee/storestich') }}">
    {{ csrf_field() }}
    <div class="row">
      <div class="col-md-3 ">
        <div class="form-group">
          <label for="email">Date</label>
          <input type="text" class="form-control" readonly="" id="datepicker" name="date" value="{{ '20'.date('y-m-d') }}" required>
        </div>
      </div>
      <div class="col-md-3" >
      <div class="form-group">
          <label for="Shift">Shift</label>
              <select id="shift"  class="form-control" name="shift" required>
              <option value="">Select</option>
              <option value="day">day</option>
                  <option value="night">night</option>
              </select>
          </div>
      </div>
      <div class="col-md-12"></div>
      <table class="table table-stripped table-responsive">
        <thead>
          <tr>
            <th>Machine</th>
            <th>No of Stitches</th>
            <th>Employee 1</th>
            <th>Employee 2</th>
            <th>Employee 3</th>

          </tr>
        </thead>
        <tbody>
          @foreach($machins as $machin)
          <tr>
            <td><input type="text" name="machin[]" value="{{ $machin->machin_code }}" class="form-control" readonly=""></td>

            <td><input type="text" onkeypress="return isNumberKey(event,this)" name="stitches[]" class="form-control"></td>

            <td><select class="form-control employees" name="employee_one[]"></select></td>
            <td><select class="form-control employees" name="employee_two[]"></select></td>
            <td><select class="form-control employees" name="employee_three[]"></select></td>
          </tr>
          @endforeach
        </tbody>
        <tfoot>
          <tr>
            <th>Machine</th>
            <th>No of Stitches</th>
            <th>Employee 1</th>
            <th>Employee 2</th>
            <th>Employee 3</th>
          </tr>
        </tfoot>
      </table>
      <div class="col-md-12 ">
        <div class="form-group">

          <button type="submit" class="btn btn-success">
            Save
          </button>
        </div>
      </div>
  </form>
</div>
</div>
</div>
<p id="duplicate_employee" class="duplicate"></p>
@endsection
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
  // $(document).ready(function() {
  //   var _token = $('input[name="_token"]').val();
  //   var shift = 'day';
  //   var row = "";
  //   var count = 1;
  //   $.ajax({
  //     type: 'POST',
  //     url: '{{ url("employee/employeesbyshift") }}',
  //     data: {
  //       shift: shift,
  //       _token: _token
  //     },
  //     dataType: 'json',
  //     success: function(data) {
  //       row += '<option value="">Select</option>';
  //       $.each(data, function(i, obj) {
  //         row += '<option value=' + obj.id + '>' + obj.name + '</option>';

  //         count++;
  //       });
  //       $('.employees').html(row);

  //     }
  //   });
  //   $('.employees').each(function() {
  //     $(this).attr('data-id', count);
  //     $(this).attr('id', 'employee_' + count);
  //     count++;
  //   })
  // });
  
  $(document).on('change','#shift',function(){
    var shift = $(this).val();
    var _token = $('input[name="_token"]').val();
    var row = "";
    var count = 1;
    $.ajax({
      type: 'POST',
      url: '{{ url("employee/employeesbyshift") }}',
      data: {
        shift: shift,
        _token: _token
      },
      dataType: 'json',
      success: function(data) {
        row += '<option value="">Select</option>';
        $.each(data, function(i, obj) {
          row += '<option value=' + obj.id + '>' + obj.name + '</option>';

          count++;
        });
        $('.employees').html(row);

      }
    });
    $('.employees').each(function() {
      $(this).attr('data-id', count);
      $(this).attr('id', 'employee_' + count);
      count++;
    })
  });
  // var duplicates =[];
  // $(document).on('change','.employees',function(){
  //        var id = $(this).attr('data-id');
  //        var value = $('#employee_'+id).val();

  //        if(duplicates.indexOf(value) < 0)
  //         { 
  //           duplicates.push(value);
  //           console.log(duplicates);
  //         }
  //         else{
  //           alert("This Employee Already selected");
  //           $('#employee_'+id).val("");
  //         }

  // });
  function isNumberKey(evt, obj) {

    var charCode = (evt.which) ? evt.which : event.keyCode
    var value = obj.value;
    var dotcontains = value.indexOf(".") != -1;
    if (dotcontains)
      if (charCode == 46) return false;
    if (charCode == 46) return true;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
      return false;
    return true;
  }
</script>