@extends('layouts.master')
@section('title', 'Accounts System-Employee')
@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">Add New Employee</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="{{ url('employee/view') }}">All Employees</a>
      </li>
      
    </ul>
<br>
<div class="col-md-12">
<h3>Create New Employee</h3>
<hr>
@if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
<form class="form-horizontal" method="POST" action="{{ url('employee/store') }}">
                        {{ csrf_field() }}
<div class="row">
<div class="col-md-3">
                            <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                                <label for="name">Name</label>

                                
                                    <input id="name" type="text" class="form-control" name="name" value="{{ old('name') }}" required autofocus placeholder="Enter Name" autofocus>

                                    @if ($errors->has('name'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('name') }}</strong>
                                        </span>
                                    @endif
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                <label for="email">Salary</label>

                                
                                    <input id="email" type="text" class="form-control" name="salary" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" value="{{ old('salary') }}" required placeholder="Enter Employee Salary">

                                    @if ($errors->has('email'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('email') }}</strong>
                                        </span>
                                    @endif
                            </div>
                        </div>
                      <!--    <div class="col-md-3 col-md-offset-4" >
                        <div class="form-group">
                            <label for="Role">Machine Man</label>
                            <input type='checkbox' class="form-control" name="mm">
                                   
                            </div>
                        </div>
                        <div class="col-md-3" >
                        <div class="form-group">
                            <label for="Role">Shift</label>
                                <select id="role"  class="form-control" name="shift" required>
                                <option value="">Select</option>
                                <option value="day">day</option>
                                    <option value="night">night</option>
                                </select>
                            </div>
                        </div> -->
                        <div class="col-md-12 ">
                        <div class="form-group">
                            
                                <button type="submit" class="btn btn-success">
                                    Create Employee
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
   
@endsection
