@extends('layouts.master')

@section('title', 'Accounts System-Attendence')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >Employees Attendance by Date</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('employee/view') }}">Add New Employee</a>
  </li>
  
</ul><br>
@if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <h3>Employees Attendance by Date</h3> 
    <form id="form" action="{{ url('employee/updateattendecs') }}" method="POST">
        {{ csrf_field() }}
    <div class="row">
    <div class="col-md-3"><input class="form-control" type="text" readonly="" value="<?php echo '20'.date('y-m-d'); ?>" id="datepicker" name='date'></div></div>
    <hr>

   <table class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            
            <th>Employee Id</th>
            <th>Employee Name</th>
            <th>Attendence</th>
            <th>Revert</th>
        </tr>
        </thead>
    <tbody id='result'>
    </tbody>
    <tfoot>
            <tr>
            
            <th>Employee Id</th>
            <th>Employee Name</th>
            <th>Attendence</th>
            <th>Revert</th>
            </tr>
    </tfoot>
    </table>
    <!-- <button class="btn btn-info" id="save">Update</button>     -->
    </form>
    
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
$(document).ready(function(){

// alert("working");
    var _token = $('input[name="_token"]').val();
    var date="{{ date('Y-m-d') }}";
    $.ajax({
         type: 'POST',
         url: '{{ url("employee/allattendence") }}',
         data: { date:date,_token:_token },
         success: function(data){
           // alert(data);
            var offset=0;
                 var count=1;
                var row="";
                 $.each(data, function (index, obj) {
                    row += "<tr><input type='hidden' name='rec_id[]' readonly value="+ obj.id +" class='form-control' data-id="+count+"><td><input type='text' name='employee[]' readonly value="+ obj.empid +" class='form-control empid' data-id="+count+"></td><td>"+obj.name+"</td>";
                    if(obj.attendence == 1){
                    row +="<td><p class='text text-success'>Present</p></td>";
                     row +="<td><a href='{{ url('employee/updateattendecs/') }}/"+obj.empid+"/"+date+"/1' class='btn btn-info'>Revert</a></td>";
                     }
                     else{
                        row +="<td><p class='text text-danger'>absent</p></td>";
                         row +="<td><a href='{{ url('employee/updateattendecs/') }}/"+obj.empid+"/"+date+"/0' class='btn btn-info'>Revert</a></td>";
                         row +="</tr>";
                     }
                   
                     offset++;
                   count++;
                });
                $('#result').html(row);
         }
      });
 $(document).on('change','#datepicker',function(){
   // alert("working");
    var _token = $('input[name="_token"]').val();
    var date=$(this).val();
    $.ajax({
         type: 'POST',
         url: '{{ url("employee/allattendence") }}',
         data: { date:date,_token:_token },
         success: function(data){
           // alert(data);
            var offset=0;
                 var count=1;
                var row="";
                 $.each(data, function (index, obj) {
                    row += "<tr><input type='hidden' name='rec_id[]' readonly value="+ obj.id +" class='form-control' data-id="+count+"><td><input type='text' name='employee[]' readonly value="+ obj.empid +" class='form-control empid' data-id="+count+"></td><td>"+obj.name+"</td>";
                    if(obj.attendence == 1){
                    row +="<td><p class='text text-success'>Present</p></td>";
                     row +="<td><a href='{{ url('employee/updateattendecs/') }}/"+obj.empid+"/"+date+"/1' class='btn btn-info'>Revert</a></td>";
                     }
                     else{
                        row +="<td><p class='text text-danger'>absent</p></td>";
                         row +="<td><a href='{{ url('employee/updateattendecs/') }}/"+obj.empid+"/"+date+"/0' class='btn btn-info'>Revert</a></td>";
                         row +="</tr>";
                     }
                   
                     offset++;
                   count++;
                });
                $('#result').html(row);
         }
      });
});
})

// $(document).on('click','.overtime',function(){
//     var dataid=$(this).attr('data-id');
//      if($('#overtime_'+dataid).is(':checked')){
//       $('#attend_'+dataid).attr('checked',true);
//       attendence=1;
//      }
//      else{
//       alert('i am here');
//        $('#attend_'+dataid).attr('checked',false);
//        attendence=0;
//      }
// });
// $(document).on('click','#save',function(){
//     var _token = $('input[name="_token"]').val();
//     var attendence=0;
//     var overtime=0;
//     var message="";
//     $('.empid').each(function(i,ob){
//         var empid=$(this).val();
//         var empdataid=$(this).attr('data-id');
//         var attend=$('.attend_'+empdataid).val();
//         var date=$('#datepicker').val();
//         if($('#overtime_'+empdataid).is(':checked')){

//            overtime=1;
//         }
//         else{
//            overtime=0;
//         }
        
//         if($('#attend_'+empdataid).is(':checked')){
//            attendence=1;
//         }
//         else{
//            attendence=0;
//         }
//         $.ajax({
//          type: 'POST',
//          url: '{{ url("employee/doattendence") }}',
//          data: { empid:empid,attendence:attendence,overtime:overtime,date:date,_token:_token },
//          success: function(data){
          
//          }
//         });

//     })
//     alert('Attendence done');
//     $('.attend').attr('checked',false);
//     $('.overtime').attr('checked',false);
// });

</script>