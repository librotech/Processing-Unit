@extends('layouts.master')
@section('title', 'Accounts System-Pay Roll')
@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">Payroll</a>
      </li>
      <li class="nav-item">
       <!--  <a class="nav-link" href="{{ url('employee/view') }}">All Employees</a>
     -->  </li>
      
    </ul>
<br>
<div class="col-md-12">
<h3>Employee's Pay Details</h3>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-success">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
     <hr>
    <form class="form-horizontal" method="POST" action="{{ url('payroll/savepayroll') }}">
                {{ csrf_field() }}

                <div class="row">
                <div class="col-md-3">
                   <div class="form-group">
                    <label for="Role"><b>Employee Name</b></label>
                        <select id="emp"  class="form-control" name="emp" required>
                            <option value="">Select</option>
                            @foreach($employees as $employee)
                            <option value="{{ $employee->id }}">{{ $employee->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-3 ">
                 <div class="form-group">
                    <label for="textbox"><b>Salary</b></label>
                    <input  type="text" class="form-control" readonly="" id="salary" name="salary"  required>
                  </div>
                </div>
                <div class="col-md-3 ">
                 <div class="form-group">
                    <label for="textbox"><b>Liabilities</b></label>
                    <input  type="text" class="form-control" readonly="" id="liability" name="liability"  required>
                  </div>
                </div>
                
                <div class="col-md-3">
                    <div class="form-group">
                    <label for="textbox"><b>Advance Taken</b></label>
                    <input  type="text" class="form-control" readonly="" id="advtaken" name="advancetaken">
                  </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                    <label for="textbox"><b>Advance Adjustment</b></label>
                    <input  type="text" value="0" class="form-control"  id="adadv" name="adadv">
                  </div>
                </div>
                <!--<div class="col-md-3">-->
                <!--    <div class="form-group">-->
                <!--    <label for="textbox"><b>Bonus</b></label>-->
                <!--    <input  type="text" value="0" class="form-control"  id="bonus" name="bonus">-->
                <!--  </div>-->
                <!--</div>-->
                <div class="col-md-3" style="display:none;">
                    <div class="form-group">
                    <label for="textbox"><b>Over Time Bounses</b></label>
                    <input  type="text" class="form-control"  id="otbounus" value="0" name="otbounus"  >
                  </div>
                </div>
                 <div class="col-md-3">
                    <div class="form-group">
                    <label for="textbox"><b>Cash Pay</b></label>
                    <input  type="text" value="0" class="form-control"  id="cpaid" name="cpaid"  >
                  </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                    <label for="textbox"><b>Total</b></label>
                    <input  type="text" value="0" class="form-control"  id="total" name="total" readonly="readonly">
                  </div>
                </div>
                <div class="col-md-12 ">
                    
                <div class="form-group">
                    
                        <button type="submit" class="btn btn-success" id="save">
                           Save
                        </button>
                    </div>
                    <br><br>
                </div>
                <div class="col-md-12"><hr></div>
                <div class="col-md-12">
                    <p id="bonusmessage"></p>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="textbox"><b>Pay Bonus</b></label>
                        <input  type="text" value="0" class="form-control"  id="bonus" name="bonus">
                   </div>
                </div>
                 <div class="col-md-8"></div>
                 <div class="col-md-2">
                    <button type="button" class="btn btn-info" id="savebonus">Save Bonus</button>
                </div>
                <div class="col-md-12"><hr></div>
                <div class="col-md-12">
                    <p id="padmessage"></p>
                </div>
                <div class="col-md-4">
                 <div class="form-group">
                    <label for="textbox"><b>Advance</b></label>
                    <input id="padvance" type="text" class="form-control" name="advance" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" placeholder="Pay Advance">
                    
                  </div>
                </div>
                   <div class="col-md-3">
                        <div class="form-group"  id="coamain">
                        <label><b>Accounts Available</b></label>
                        <select class="form-control" name="coa"  id="coa">
                            @foreach($chartofaccounts as $chartofaccount)
                            <option value="{{ $chartofaccount->acc_id }}">{{ $chartofaccount->acc_title }}</option>
                            @endforeach
                        </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group"  id="coabal">
                            <label><b>Cash Available</b></label>
                        <input type="number"  readonly="readonly" name="cash_available" id="total_coa_balance" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-2"></div>
                    <div class="col-md-12"><button type="button" class="btn btn-success" id="padv">Pay Advance</button></div>
                  </form>
                </div>
            </div>
        </div>
   
@endsection
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
$(document).on('change', '#emp', function(){
  var _token = $('input[name="_token"]').val();
  var emp=this.value;
    $.ajax({
         type: 'POST',
         url: '{{ url("payroll/getemplyeesalary") }}',
         data: { emp:emp,_token:_token },
         dataType:'json',
         success: function(data){
        
          $('#salary').val(data[0]);
          $('#advtaken').val(data[1]);
          $('#liability').val(data[2]);
          if(data[1] < 1){
              $('#adadv').attr('readonly',true);
          }else{
              $('#adadv').attr('readonly',false);
          }

         }
      });
      $('#adadv').val(0);
      $('#cpaid').val(0);
      $('#total').val(0);
});

$(document).on('change','#cpaid,#adadv',function(){
  var total = 0;
  var liability = $('#liability').val();
  
      if($('#adadv').val() == ""){
        $('#save').attr('disabled',false);
        if(parseInt($('#adadv').val()) > parseInt($('#advtaken').val())){
            $('#save').attr('disabled',true);
        }
        $('#adadv').val(0);
      }
      else if($('#cpaid').val() == "")
       {
       $('#cpaid').val(0);
       }
   total = parseFloat($('#cpaid').val())+parseFloat($('#adadv').val());
   $('#total').val(total);
    if(liability > total)
        $('#save').attr('disabled',false);
    else
         $('#save').attr('disabled',true);
});


// $(document).on('change','#adadv',function(){
  
  
//   var advance = $(this).val();
//   var advtaken = $('#advtaken').val();
//   var cpaid = $('#cpaid').val();
//   var bonus = $('#bonus').val();
//   var liability = $('#liability').val();
//   var total =0;
//   if(parseInt(advance) <=  parseInt(advtaken)){
     
//       $('#save').attr('disabled',false);
//           if(parseInt(advance) > 0 && parseInt(cpaid) == 0 && parseInt(bonus) == 0){
//                 alert('working');
//                     total =parseInt(advance);
//           }
//           else if(parseInt(advance) > 0 && parseInt(cpaid) > 0 && parseInt(bonus) == 0){
//              total =parseInt(cpaid)+parseInt(advance); 
//           }
//          else if(parseInt(advance) > 0 && parseInt(cpaid) > 0 && parseInt(bonus) > 0){
//              total = parseInt(cpaid)+parseInt(advance)+parseInt(bonus);
//              }
//          $('#total').val(total);
//       }
      
      
//       else{
//           $('#save').attr('disabled',true);
//       }
  
//   if(liability > total)
//         $('#save').attr('disabled',false);
//     else
//          $('#save').attr('disabled',true);
  
   
// });

$(document).on('click','#savebonus',function(){
    var emp=$('#emp').val();
    var bonus = $('#bonus').val();
    var _token = $('input[name="_token"]').val();
    if(bonus !="" && emp != ""){
        $.ajax({
            url:'{{ url("bonus/save") }}',
            type:'POST',
            data:{ emp:emp,_token:_token,bonus:bonus },
            success:function(res){
                console.log(res);
               $('#bonusmessage').fadeIn('slow');
               $('#bonusmessage').attr('class','alert alert-success')
               $('#bonusmessage').html('Bonus Given');
               $('#bonusmessage').fadeOut(3000);
               $('#bonusmessage').val("");
            }
        })
    }
    else{
         $('#bonusmessage').fadeIn('slow');
          $('#bonusmessage').attr('class','alert alert-danger')
          $('#bonusmessage').html('Please Select Employee First Or See if Bonus Field Is Not Empty');
          $('#bonusmessage').fadeOut(3000);
    }
})

$(document).on('click','#padv',function(){
    var advance = $('#padvance').val();
    var coa = $('#coa').val();
    var emp=$('#emp').val();
    if(advance != "" && emp != ""){
       var _token = $('input[name="_token"]').val();
      
        $.ajax({
             type: 'POST',
             url: '{{ url("payroll/payadvance") }}',
             data: { coa:coa,advance:advance,emp:emp,_token:_token },
             success: function(data){
                if(data != ""){
                       $('#padmessage').fadeIn('slow');
                       $('#padmessage').attr('class','alert alert-success')
                       $('#padmessage').html('Advance Paid');
                       $('#padmessage').fadeOut(3000);
                       $('#padvance').val("");
                }
             }
          });
    }
    else{
        $('#padmessage').fadeIn('slow');
          $('#padmessage').attr('class','alert alert-danger')
          $('#padmessage').html('Please Select Employee First Or See if Advance Field Is Not Empty');
          $('#padmessage').fadeOut(3000);
    }
    
});

$(document).ready(function(){
    if($('#coa').val() == null){
      // alert("working");
      $('#save').attr('disabled',true);
      $('#padv').attr('disabled',true);
      $('#save').html("Please Make Cash Paid Relationship First");
      $('#padv').html("Please Make Cash Paid Relationship First");
    }
    $('#padvance').change(function(){
        var padvance = $(this).val();
        if(parseInt(padvance) > parseInt($('#total_coa_balance').val())){

            $('#padv').css('display','none');
        }
        if(parseInt(padvance) < parseInt($('#total_coa_balance').val())){
            $('#padv').css('display','block');
        }
       

    });
    var _token = $('input[name="_token"]').val();
    var coa1 =$('#coa').val();
     $.ajax({
            type:'POST',
            url:'{{ url("purchase/gettotalbalance") }}',
            data:{coa1:coa1,_token:_token},
            success:function(data){
                $('#total_coa_balance').val(data);

                if(parseInt(data) < parseInt($('#padvance').val()) ){
                    $('#padv').css('display','none');
                }
                else if (parseInt(data) > parseInt($('#padvance').val()) ) {
                    $('#padv').css('display','block');
                }
            }
        });
    $('#coa').change(function(){ 
        var coa =$(this).val();
        $.ajax({
            type:'POST',
            url:'{{ url("purchase/gettotalbalance") }}',
            data:{coa:coa,_token:_token},
            success:function(data){
                $('#total_coa_balance').val("");
                $('#total_coa_balance').val(data);

                if(parseInt(data) < parseInt($("#padvance").val()) ){
                    $('#padv').css('display','none');
                }
                else if (parseInt(data) > parseInt($("#padvance").val()) ) {
                    $('#padv').css('display','block');
                }
            }
        });
    });
    
});
</script>