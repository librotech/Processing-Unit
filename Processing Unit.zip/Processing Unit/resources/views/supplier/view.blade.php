@extends('layouts.master')

@section('title', 'Accounts System-Suppliers')

@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >View supplier</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('supplier/add') }}">Add New Supplier</a>
  </li>

</ul><br>
    <h3>All Suppliers</h3> <a href="{{ url('supplier/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Add New Supplier</a>
    <hr>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
            <th>SNo.</th>
            <th>Supplier_id</th>
            <th>Supplier</th>
            <th>Supplier Address</th>
            <th>user</th>
            <th>Date</th>
            <th>Edit</th>
            @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
            </tr>
        </thead>
        <tbody>
            @foreach($suppliers as $supplier)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $supplier->supplier_id }}</td>
                <td>{{ $supplier->supplier_name }}</td>
                <td>{{ $supplier->addres }}</td>
                <td>{{ $supplier->name }}</td>
                <td>{{ date('d-m-Y', strtotime($supplier->created_at))}}</td>
                 <td><a href="{{ url('supplier/show/'.$supplier->id)}}" class="btn btn-success btn-sm">Edit</a></td>
                @if(Auth::user()->role == 1)
                <td><a href="{{ url('supplier/delete/'.$supplier->id) }}" class="btn btn-danger btn-sm" onclick="return confirm(' you want to delete?');">Delete</a></td>
                @endif
            </tr>
            @endforeach
        </tbody>
        <tfoot>
            <tr>
            <th>SNo.</th>
            <th>Supplier_id</th>
            <th>Supplier</th>
            <th>Supplier Address</th>
            <th>user</th>
            <th>Date</th>
            <th>Edit</th>
            @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
            </tr>
        </tfoot>
    </table>
@stop
