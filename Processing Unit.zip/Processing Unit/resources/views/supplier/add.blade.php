@extends('layouts.master')

@section('title', 'Accounts System-Suppliers')

@section('content')

<ul class="nav nav-tabs">
   <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('supplier/show') }}">View suppliers</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >Add New Supplier</a>
  </li>
</ul><br>
    <h3>Add New Supplier</h3>
    <a href="{{ url('supplier/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Suppliers</a>
    <hr>
    @if(count($errors) > 0)
    	@foreach($errors->all() as $error)
    		<p class="alert alert-danger">{{ $error }}</p>
    	@endforeach
    @endif
	    @if(session()->has('message.level'))
	    <div class="alert alert-{{ session('message.level') }}"> 
	    {!! session('message.content') !!}
	    </div>
		@endif
    <form action="{{ url('supplier.store') }}" method="post">
    	{{ csrf_field() }}
        <div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <label>Supplier Id</label>
                @foreach($auto_increment as $ai)
                <input type="number" value='{{ $ai->AUTO_INCREMENT }}' name="txt_supplier_id" class="form-control" placeholder="Enter Suuplier Id">
                @endforeach
            </div>
        </div><div class="col-md-3">
            <div class="form-group">
                <label>Supplier Name</label>
                <input type="text" required="required" name="txt_supplier_name" class="form-control" placeholder="Enter Supplier Name">
            </div>
            
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Address</label>
                <textarea class="form-control" required="required" style="overflow:auto;resize:none" rows="3" cols="3" name="supplier_address"></textarea>
            </div> 
        </div>

        </div>
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
        <button class="btn btn-block btn-success">Save</button></div></div>
    </form>
@stop
