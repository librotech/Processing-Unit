@extends('layouts.master')

@section('title', 'Accounts System-Customers')

@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >View Customers</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('customer/add') }}">Add New Customer</a>
  </li>
</ul><br>
    <h3>All Customers</h3> <a href="{{ url('customer/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Add New Customer</a>
    <hr>

   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
           <th>SNo.</th>
            <th>Customer Id</th>
            <th>Customer Name</th>
            <th>Credit Limit</th>
            <th>Credit Sales</th>
            <th>user</th>
            <th>Date</th>
            <th>Edit</th>
            @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
        </tr>
        </thead>
        <tbody>
            

        @foreach($customers as $customer)
            <?php
            $credit_sales="";
            if($customer->credit_sales == 1){
                $credit_sales="yes";
            }
            else {
                 $credit_sales="no";
            }
            ?>
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $customer->customer_id }}</td>
                <td>{{ $customer->customer_name }}</td>
                <td>{{ $customer->credit_limit }}</td>
                <td>{{ $credit_sales }}</td>
                <td>{{ $customer->name }}</td>
                <td>{{ $customer->created_at }}</td>
               
                <td><a href="{{ url('customer/show/'.$customer->id)}}" class="btn btn-success btn-sm">Edit</a></td>
                @if(Auth::user()->role == 1)
                 <td><a href="{{ url('customer/delete/'.$customer->id) }}" class="btn btn-danger btn-sm" onclick="return confirm(' you want to delete?');">Delete</a></td>
                @endif
            </tr>
            
        @endforeach
    </tbody>
    <tfoot>
            <tr>
             <th>SNo.</th>
            <th>Customer Id</th>
            <th>Customer Name</th>
            <th>Credit Limit</th>
            <th>Credit Sales</th>
            <th>user</th>
            <th>Date</th>
            <th>Edit</th>
            @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
            </tr>
        </tfoot>
    </table>

    
@stop
