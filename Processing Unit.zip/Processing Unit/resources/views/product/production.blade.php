@extends('layouts.master')
@section('title', 'Accounts System-Add New sales')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('product/production_show') }}">View Production</a>
  </li>
  
</ul><br>
    <h3>Production</h3>
     <a href="{{ url('product/production_show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Production</a>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form action="{{ url('product/production_save') }}" id="myForm" method="post">
   <div class="row">
   <div class="col-md-3">

          @foreach($auto_increment as $ai)
          <input type="hidden" name="txt_inv_no" value="{{ $ai->AUTO_INCREMENT }}" class="form-control" readonly="readonly" id="inv_id">
          @endforeach

        <label>Raw Products</label>
         <input type="text" required="required" data-id="1" id="product_id"  name="txt_product_id" class="form-control product_id" autocomplete="no" placeholder="Product" list="products" autofocus>
          <datalist id="products">
          @foreach($products as $r)
              <option value="{{ $r->product_id }}"><b>{{ $r->product_description }}</b></option>
          @endforeach
          </datalist>
 
        </div>
         <div class="col-md-3">
            <label>Bags</label>
            <input required="required" type="number"   id="bags" name="bags" class="form-control bags bags1" placeholder="Number of Bags">
            <input required="required" type="hidden"   id="pro_price" name="pro_price" class="form-control pro_price pro_price1" placeholder="Number of price">
        </div>

        

        <div class="col-md-3">
            <label>Kg</label>
            <input type="text"  onkeypress="return isNumberKey(event,this)" id="kg"   name="kg"  class="form-control kg kg1" placeholder="Weight in kg">
        </div>

       
         <div class="col-md-3">
             <label>Total Weight</label>
            <input required="required" type="text"  onkeypress="return isNumberKey(event,this)" id="tweight" name="tweight" class="form-control tweight tweight1" placeholder="Number of Weights" readonly="">
            <input type="hidden" name="hidden" id="hidden" class=" form-control hidden hidden1">
        </div>
      </div>
      <!-- <div class="row"> -->
      <hr>

        <h3>Finalized Products</h3>
        <table class="table table-hover order-list">
          <thead>
          <tr>
            <th>Product</th>
            <th>Name</th>
            <th>Bags</th>
            <th>Cost Price</th>
          </tr>
          </thead>
          <tbody>
          <tr>
            <td>
              <input  type="text" required="required" data-id="1"  name="txt_byproduct_id1" class="form-control byproduct byproduct1" autocomplete="no" placeholder="Product" list="byproducts" autofocus>
                    <datalist class="byproducts1" id="byproducts">
                    </datalist>
            </td>
            <td>
              <input type="text"  readonly="readonly"  name="txt_byproduct_description1" tabindex="-1" class="form-control pro_des pro_des1" placeholder="Product Name">
            </td>
            <td>
             <input required="required" type="text"  onkeypress="return isNumberKey(event,this)" id="np_weight" name="np_weight1" class="form-control np_weight np_weight1" placeholder="Number of bags" >

              <input required="required" type="hidden"  onkeypress="return isNumberKey(event,this)" id="weight" name="weight1" class="form-control weight weight1" placeholder="Number of Weights" >
            </td>

            <td>
              <input required="required" type="hidden"  onkeypress="return isNumberKey(event,this)" id="t_weight" name="t_weight1" class="form-control t_weight t_weight1" placeholder="Number of Weights" >
              <input type="text" required="required" data-id="1"  name="byprice1" class="form-control price price1" autocomplete="no" placeholder="price" list="price" autofocus>
            </td>  

            <td><input type="button" id="addrow" value="Add More" class="btn btn-success"></td>

          </tr>
        </tbody>

      </table>
        <!-- </div> -->
      
         <!-- <div class="row dataToBeShow"> -->
             
             <!-- </div> -->
             <!-- <div class="row"> -->
              <hr>
               <div class="form-group">

                <div class="col-md-3">
                 <label>Total Weight Used</label>
                 <input  type="text"  onkeypress="return isNumberKey(event,this)" id="total_weight" name="total_weight" class="form-control total_weight total_weight" placeholder="total weight used" readonly="">
               </div>
               <br>
                <div class="col-md-3">
                 <label>Total Weight Produced</label>
                 <input  type="text"  onkeypress="return isNumberKey(event,this)" id="total_produce" name="total_produce" class="form-control total_produce total_produce" placeholder="total weight of Production" readonly="">
               </div>
               <br>
                <div class="col-md-3">
                 <label>Yield</label>
                 <input  type="text"  onkeypress="return isNumberKey(event,this)" id="yield" name="yield" class="form-control yield yield1" placeholder="yield" readonly="">
               </div>
               <br>
                <div class="col-md-3">
                  <button id="submit" class="btn btn-block btn-success">Save</button>
                </div>
             </div>
             <!-- <div class="col-md-6"></div> -->
             <!-- </div> -->
        {{ csrf_field() }}
    </form>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script>
$(document).ready(function () {

    var counter = 1;
    $(".order-list").on("keydown",'.qty', function (e) {
        if( e.which == 9 || e.which == 13){
             counter++;
        var newRow = $("<tr>");
        var cols = "";
        cols += '<td> <input  type="text" required="required" data-id="'+counter+'"  name="txt_byproduct_id[]" class="form-control byproduct byproduct'+counter+'" autocomplete="no" placeholder="Product" list="byproducts" autofocus><datalist class="byproducts'+counter+'" id="byproducts"></datalist>';


        cols += '<td><input type="text"  readonly="readonly"  name="txt_byproduct_description[]" tabindex="-1" class="form-control pro_des pro_des'+counter+'" placeholder="Product Name"></td>';

        cols += '<td><input required="required" type="text"  onkeypress="return isNumberKey(event,this)" id="np_weight" name="np_weight[]" class="form-control np_weight np_weight'+counter+'" placeholder="Number of Weights"></td><input required="required" type="hidden"  onkeypress="return isNumberKey(event,this)" id="weight" name="weight1" class="form-control weight weight'+counter+'" placeholder="Number of Weights" >';

        cols += '<td><input required="required" type="hidden"  onkeypress="return isNumberKey(event,this)" id="t_weight" name="t_weight[]" class="form-control t_weight t_weight'+counter+'" placeholder="Number of Weights" ><input type="text" required="required" data-id="1"  name="byprice[]" class="form-control price'+counter+'" autocomplete="no" placeholder="price" list="price" autofocus></td>';

        cols += '<td><a class="deleteRow btn btn-danger"> x </a></td>';
        newRow.append(cols);
        
        $("table.order-list").append(newRow);
        }
    });
    
   $("table.order-list").on("change", '.np_weight ,.weight', function (event) {
          calculateRow($(this).closest("tr"));
          calculateGrandTotal();
      });
    
    $("table.order-list").on("click", "a.deleteRow", function (event) {
        $(this).closest("tr").remove();
        calculateGrandTotal();
            });
    $("#addrow").on("click", function () {
        counter++;
        
        var newRow = $("<tr>");
        var cols = "";
            cols += '<td> <input  type="text" required="required" data-id="'+counter+'"  name="txt_byproduct_id[]" class="form-control byproduct byproduct'+counter+'" autocomplete="no" placeholder="Product" list="byproducts" autofocus><datalist class="byproducts'+counter+'" id="byproducts"></datalist>';


        cols += '<td><input type="text"  readonly="readonly"  name="txt_byproduct_description[]" tabindex="-1" class="form-control pro_des pro_des'+counter+'" placeholder="Product Name"></td>';

        cols += '<td><input required="required" type="text"  onkeypress="return isNumberKey(event,this)" id="np_weight" name="np_weight[]" class="form-control np_weight np_weight'+counter+'" placeholder="Number of Weights"></td><input required="required" type="hidden"  onkeypress="return isNumberKey(event,this)" id="weight" name="weight[]" class="form-control weight weight'+counter+'" placeholder="Number of Weights" >';

        cols += '<td><input required="required" type="hidden"  onkeypress="return isNumberKey(event,this)" id="t_weight" name="t_weight[]" class="form-control t_weight t_weight'+counter+'" placeholder="Number of Weights" ><input type="text" required="required" data-id="1"  name="byprice[]" class="form-control price price'+counter+'" autocomplete="no" placeholder="price" list="price" autofocus></td>';

        cols += '<td><a class="deleteRow btn btn-danger"> x </a></td>';
        
        newRow.append(cols);
        
        $("table.order-list").append(newRow);
    });
   $("table.order-list").on("change", '.np_weight,.product_id, .weight', function (event) {
          calculateRow($(this).closest("tr"));
          calculateGrandTotal();
      });
    
    $("table.order-list").on("click", "a.deleteRow", function (event) {
        $(this).closest("tr").remove();
        removeRowCalculateTotal();

    });
});


$(document).on('change' ,'#product_id',function(){
    var _token = $('input[name="_token"]').val();
    var product=this.value;

    $.ajax({

      type:'POST',
      dataType:'json',
      url:'{{url("product/price")}}',
      data:{product:product,_token:_token},
      success:function(data){
        // alert(data);
        $('.pro_price').val(data);
      }
    })
})

$(document).on('change', '.product_id', '.bags', function(){
 var _token = $('input[name="_token"]').val();
    var product=this.value;
    var pro_id=$(this).attr('data-id');
          $.ajax({
           type: 'POST',
            dataType: 'json',
          url: '{{ url("product/production_product") }}',
          data: { product:product,_token:_token },
          success: function(data){
            // alert(data);
            var option = '';
            $.each(data[0],function(index,object){
                // console.log(object.product_id,object.name);
             
                option += '<option value='+object.product_id+'>'+object.name+'</option>'
            })

            $('#byproducts').html(option);
            
         }
      });
           
});
$(document).on('change', '.byproduct',  function(){
    var _token = $('input[name="_token"]').val();
    var by_id=this.value;

    var pro_id=$(this).attr('data-id');
        $.ajax({
          type: 'POST',
          url: '{{ url("product/populate_product") }}',
          data: { by_id:by_id,_token:_token },
          success: function(data){
         
          $('.pro_des'+pro_id).val(data[0]);
          $('.price'+pro_id).val(data[1]);
          $('.weight'+pro_id).val(data[2]);
         
         }
      });
           
});


function calculateRow(row) { 

   var bags =+ row.find('.np_weight').val();
   var weight =+ row.find('.weight').val();
   var totalWeight = $('.tweight').val();
   
   var t_weight = parseFloat(bags)*parseFloat(weight);
   row.find('.t_weight').val((t_weight).toFixed(2));

   

}

function removeRowCalculateTotal(){
  var a= 0;
    $("table.order-list").find('.t_weight').each(function () {
       a +=parseFloat($(this).val());
      $('.total_produce').val(a.toFixed(2)); 
    });
    // var a = $('.t_weight').val();
    var b = $('.tweight').val();
    var cal = (a/b)*100;      
    $('.yield').val((cal).toFixed(2));
}

function calculateGrandTotal(){
$(document).on('change','.t_weight, .tweight ,.np_weight, .bags, .kg',function(){
    var a= 0;
    $("table.order-list").find('.t_weight').each(function () {
       a +=parseFloat($(this).val());
      $('.total_produce').val(a.toFixed(2)); 
    });
    // var a = $('.t_weight').val();
    var b = $('.tweight').val();
    var cal = (a/b)*100;      
    $('.yield').val((cal).toFixed(2));

  });

}

$(document).ready(function(){
  $('.bags, .kg').keyup( function(){
    var bags = $('.bags').val();
    var kg = $('.kg').val();
    if(kg == '' )
      kg=0;
    else
    var kg = $('.kg').val();
    var weight = bags*65;

    $('#tweight').val((parseFloat(weight)+parseFloat(kg)));
    $('#total_weight').val((parseFloat(weight)+parseFloat(kg)));

    
  
});

});
$(document).ready(function(){
  $('.bags').keyup( function(){

    var bags = $('.bags').val();
    var weight = $('.hidden').val();
    // alert(weight);
    // alert(bags);
    // alert(weight);
    if(bags != ''){
       $('.weight').val(bags * weight);
    }else{
        $('.weight').val(weight);
    }
});
});

function isNumberKey(evt, obj) {

            var charCode = (evt.which) ? evt.which : event.keyCode
            var value = obj.value;
            var dotcontains = value.indexOf(".") != -1;
            if (dotcontains)
                if (charCode == 46) return false;
            if (charCode == 46) return true;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
        }
</script>
  
   