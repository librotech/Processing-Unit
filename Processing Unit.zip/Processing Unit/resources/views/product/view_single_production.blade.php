
@extends('layouts.master')

@section('title', 'Accounts System-Production')

@section('content')
<ul class="nav nav-tabs">
     <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >View Products</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('product/production') }}">Add New Production</a>
  </li>
 
</ul><br>
    <h3>All Products</h3> <a href="{{ url('product/production') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Add New Production</a>
    <hr>
    
   
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
            <th>SNo.</th>
            <th>Product id</th>
            <th>Product Name</th>
            <th>Weight</th>
            <th>Date</th>
           
            </tr>
        </thead>
        <tbody>
            @foreach($byproducts as $product)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $product->product_id }}</td>
                <td>{{ $product->name }}</td>
                <td>{{ $product->weight }}</td>
                <td>{{ date('d-m-Y', strtotime($product->created_at))}}</td>
            </tr>
            @endforeach
        </tbody>
        <tfoot>
            <tr>
            <th>SNo.</th>
            <th>Product id</th>
            <th>Product Name</th>
            <th>Weight</th>
            <th>Date</th>
           
            </tr>
        </tfoot>
    </table>
    
    

@stop
