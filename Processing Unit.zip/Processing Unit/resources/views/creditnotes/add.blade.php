@extends('layouts.master')

@section('title', 'Accounts System-Return Sale')

@section('content')
 <ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active"  >Return Sale</a>
      </li>
      <li class="nav-item">
        <a class="nav-link "  href="{{ url('creditnotes/view') }}">All Sales Return</a>
      </li>
    </ul>
<br>
    <h3>Return Sale</h3>
    <a href="{{ url('creditnotes/view') }}" class="btn btn-info" style="float:right;margin-top:-40px;">All Sales Return</a>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form action="{{ url('creditnotes/save') }}" id="myForm" method="post">

    	<div class="row">
    	<div class="col-md-3">
    		<div class="form-group">
                <label>Customer Name</label>
                <select class="form-control" required="required" name="txt_customer" id="customer" autofocus>
                    <option value="">Select</option>
                    @foreach($customers as $customer)
                    <option value="{{ $customer->customer_id }}">{{ $customer->customer_name }}</option>
                    @endforeach
                    
                </select>
            </div>
    		
    	</div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Date</label>
                <input type="text" readonly="readonly" value="<?php echo "20".date('y-m-d', time()); ?>" id="datepicker" style="background:white !important;" name="txt_date" class="form-control">
            </div>
        </div>
        <div class="col-md-3">
        <div class="form-group">
            <label>Sale Invoice No</label>
            <input type="text" name="bill" required="required" class="form-control bill bill1" autocomplete="off" placeholder="Bill Id" list="bills"><datalist class="bills" id="bills"></datalist>
        </div>
        </div>
    	</div>
		<table class="table table-hover order-list">
                <thead>
                <tr>
                    <th>Product</th>
                    <th>Sale Price</th>
                    <th>Quantity</th>
                    <th>Amount</th>
                    <th>Add More</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>
                    <input type="text" required="required" data-id="1"  name="txt_product_id1" class="form-control product_id pro1" placeholder="Product" autocomplete="off" list="products">
                    <datalist class="products" id="products">
                    </datalist>
                    </td>
                    <td><input type="text" id="sale_price" readonly="readonly"  name="price1" class="form-control price s_price1" placeholder="sale Price"></td>
                    <td><input type="text"  required="required" onkeypress="return isNumberKey(event,this)" id="qty" name="qty1" class="form-control qty" placeholder="Product Quantity"></td>
                    <td><input type="number" id="ammount" readonly="readonly"  name="linetotal1" class="form-control txt_amount linetotal" placeholder="Amount"></td>
                    <td><input type="button" id="addrow" value="Add More" class="btn btn-success"></td>

                </tr>
            </tbody>

        </table>
        <div class="row">
             <div class="col-md-6"></div>
               <div class="col-md-3">
                <div class="form-group" id="coamain" style="display:none;">
                <label><b>ChartofAccounts</b></label>
                <select class="form-control" name="coa" id="coa">
                    @foreach($chartofaccounts as $chartofaccount)
                    <option value="{{ $chartofaccount->acc_id }}">{{ $chartofaccount->acc_title }}</option>
                    @endforeach
                </select>
                </div>
            </div>
            <div class="col-md-3">
               <div class="form-group">
                    <label><b>Total</b></label>
                    <input type="text" readonly="readonly" id="total" name="total" class="form-control">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6"></div>
          
            <div class="col-md-3">
                <div class="form-group" id="coacash" style="display:none;">
                    <label><b>Cash Available</b></label>
                <input type="number" readonly="readonly"  name="cash_available" id="total_coa_balance" class="form-control">
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Cash Paid</b></label>
                    <input type="number" min="0"  onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" placeholder="please enter advance amount" id="cash_paid" name="cash_paid" class="form-control">
                </div>
            </div>
        </div>
         <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Due Balance</b></label>
                    <input type="number" readonly="readonly"  id="total_amount" name="total_amount" class="form-control">
                </div>
            </div>
        </div>
        <div class="row">
             <div class="col-md-9"></div>
            <div class="col-md-3"><button class="btn btn-block btn-success" id="save">save</button></div>
        </div>
        {{ csrf_field() }}
    </form>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
$(document).ready(function () {
    var counter = 1;
    
    $("#addrow").on("click", function () {
        counter++;
        
        var newRow = $("<tr>");
        var cols = "";
        cols += '<td><input type="text"  data-id="'+counter+'"  name="txt_product[]" class="form-control product_id pro'+counter+'" autocomplete="off" placeholder="Product Id" list="products"><datalist class="products" id="products"></datalist>';
        cols += '<td><input type="number"  name="price[]" readonly="readonly" class="form-control price s_price'+counter+'"/></td>';
        cols += '<td><input type="text"   onkeypress="return isNumberKey(event,this)" name="qty[]" class="form-control qty"/></td>';
        cols += '<td><input type="text" name="linetotal[]" readonly="readonly" class="form-control linetotal"/></td><input type="hidden" name="counter[]" value="'+counter+'">';
        cols += '<td><a class="deleteRow btn btn-danger"> x </a></td>';
        newRow.append(cols);
        
        $("table.order-list").append(newRow);
    });
    
    $("table.order-list").on("change", '.price, .qty', function (event) {
        calculateRow($(this).closest("tr"));
        calculateGrandTotal();
    });
    
    $("table.order-list").on("click", "a.deleteRow", function (event) {
        $(this).closest("tr").remove();
        calculateGrandTotal();
    });

    var formProcessing = false;
    $("#myForm").on("submit", function(e) {
        
        e.preventDefault();
        
        if( formProcessing )
            return;

        formProcessing = true;
        $("#myForm").get(0).submit();
        
    });

});
    
function calculateRow(row) {
    var price = +row.find('.price').val();
    var qty = +row.find('.qty').val();
    row.find('.linetotal').val((price * qty).toFixed(2));
    
}

function calculateGrandTotal() {
    var grandTotal = 0;
    $("table.order-list").find('.linetotal').each(function () {
        grandTotal += +$(this).val();
        $("#total_amount").val(grandTotal.toFixed(2));
    });
    $("#total").val(grandTotal.toFixed(2));
     $("#cash_paid").keyup(function(){
        var cash_paid=$(this).val();
        if(cash_paid != ""){
            $('#coamain').show();
            $('#coacash').show();
            $('#coa').attr('required','required');
        }
        if(cash_paid == ""){
            $('#coamain').hide();
            $('#coacash').hide();
            $('#coa').removeAttr('required');
        }
        if($('#total_coa_balance').val() != ""){
            var data =$('#total_coa_balance').val();
            if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                $('#save').css('display','none');
            }
            else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
             $('#save').css('display','block');
            }
        }
       var grandTotal= $("#total").val();
       var final_ammount =grandTotal-cash_paid;
       $("#total_amount").val(final_ammount.toFixed(2));
    })
}
    
$(document).on('change', '.product_id', function(){
 var _token = $('input[name="_token"]').val();
    var product=this.value;
    var pro_id=$(this).attr('data-id');
          $.ajax({
           type: 'POST',
            dataType: 'json',
          url: '{{ url("purchase/products") }}',
          data: { product:product,_token:_token },
          success: function(data){
            $('.s_price'+pro_id).val(data[0]);
         }
      });
});


$(document).on('change', '#customer', function(){
 var _token = $('input[name="_token"]').val();
    var customer=this.value;
          $.ajax({
           type: 'POST',
            url: '{{ url("creditnotes/getcusbills") }} ',
          data: { customer:customer,_token:_token },
          success: function(data){
            if(data != ""){
                $('.bills').html(data);
            }
            else{
                $('.bills').html("")
            }
         }
      });
});

$(document).on('change', '.bill', function(){
 var _token = $('input[name="_token"]').val();
    var bill=this.value;
    var bill_id=$(this).attr('data-id');
          $.ajax({
            type: 'POST',
          url: '{{ url("creditnotes/getbillproducts") }}',
          data: { bill:bill,_token:_token },
          success: function(data){
            $('.products').html(data);
         }
      });
});
$(document).ready(function(){
    var _token = $('input[name="_token"]').val();
    var coa1 =$('#coa').val();
     $.ajax({
            type:'POST',
            url:'{{ url("purchase/gettotalbalance") }}',
            data:{coa1:coa1,_token:_token},
            success:function(data){
                $('#total_coa_balance').val(data);

                if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                    $('#save_purchase').css('display','none');
                }
                else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
                    $('#save_purchase').css('display','block');
                }
            }
        });
    $('#coa').change(function(){ 
        var coa =$(this).val();
        $.ajax({
            type:'POST',
            url:'{{ url("purchase/gettotalbalance") }}',
            data:{coa:coa,_token:_token},
            success:function(data){
                $('#total_coa_balance').val("");
                $('#total_coa_balance').val(data);

                if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                    $('#save_purchase').css('display','none');
                }
                else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
                    $('#save_purchase').css('display','block');
                }
            }
        });
    });
    
});


function isNumberKey(evt, obj) {

            var charCode = (evt.which) ? evt.which : event.keyCode
            var value = obj.value;
            var dotcontains = value.indexOf(".") != -1;
            if (dotcontains)
                if (charCode == 46) return false;
            if (charCode == 46) return true;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
        }
</script