@extends('layouts.master')
<style type="text/css">
    .list-group-item.active {
        background: #385793 !important;
        border-color: #385793 !important;
        ;
    }
</style>
@section('title', 'Accounts System-Employee Stitches Report')
@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
        <a class="nav-link" href="{{ url('/home') }}">Home</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="{{ url('report/view') }}">Reports</a>
    </li>
    <li class="nav-item">
        <a class="nav-link active">Employee Stitches Report</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
</ul>
<br>
<h3 id="tableheadtext">This Week Employee Report</h3>
<hr>
@if(count($errors) > 0)
@foreach($errors->all() as $error)
<p class="alert alert-danger">{{ $error }}</p>
@endforeach
@endif
@if(session()->has('message.level'))
<div class="alert alert-{{ session('message.level') }}">
    {!! session('message.content') !!}
</div>
@endif
<ul class="nav nav-tabs" role="tablist">

    <li class="nav-item"><b>&nbsp&nbsp&nbspFrom</b>&nbsp&nbsp</li>
    <li class="nav-item">
        <input type="text" placeholder="select date" readonly="" id="datepicker" class="form-control">&nbsp
    </li>
    <li class="nav-item"><b>&nbsp&nbsp&nbspTo</b>&nbsp&nbsp</li>
    <li class="nav-item">
        <input type="text" placeholder="select date" readonly="" id="datepicker2" class="form-control">&nbsp
    </li>
</ul>
<form action="{{ url('report/employeepay') }}" method="POST">
    {{ csrf_field() }}
    <div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <lable>Customer</lable>
                <input type="text" data-id="1" required="required" id="customer" name="customer" class="form-control" placeholder="Employee" autocomplete="no" list="customers">
                <datalist class="customer" id="customers">
                    @foreach($customers as $customer)
                    <option value="{{ $customer->customer_id }}">{{ $customer->customer_name }}</option>
                    @endforeach
                </datalist>
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <lable>Customer Name</lable>
                <input type="text" data-id="1" required="required" id="customer_name" readonly class="form-control" placeholder="Customer Name">
            </div>
        </div>
    </div>
    <table class="table table-stripped" id="example">
    <thead>
        <tr><td>bill no</td><td>Transaction Type</td><td>Total</td><td>Cashpaid</td><td>DueBalance</td><td>Signed By</td><td>Date</td></tr>
    </thead>
    <tbody id="data">
 
    </tbody>
    <tfoot>
         <tr><td>bill no</td><td>Transaction Type</td><td>Total</td><td>Cashpaid</td><td>DueBalance</td><td>Signed By</td><td>Date</td></tr>
    </tfoot>
    </table>
    
</form>

<script type="text/javascript">
    $(document).on('change', '#customer,#datepicker,#datepicker2', function() {
        var fromDate = $('#datepicker').val();
        var toDate = $('#datepicker2').val();
        var table = $('#example').DataTable();
        var _token = $('input[name="_token"]').val();
        var customer = $('#customer').val();
        var employee_name = "";
        table.clear();
        if(customer != ""){
            $.ajax({
            type: 'POST',
            url: '{{ url("saledetailsreport") }}',
            data: {
                customer,
                fromDate,
                toDate,
                _token: _token
            },
            dataType: 'json',
            success: function(data) {
                var row ='';
                var cashPaid=0;
                var total = 0;
                var duebal = 0;
                $.each(data[0],function(index,obj){
                        var cpaid = obj.cashpaid
                        var crcpaid = obj.cr_cashpaid
                        if(obj.cashpaid == null)
                            cpaid ='-';
                        if(obj.cr_cashpaid == null)
                            crcpaid ='-';
                            
                    if('customer' in obj){
                        var bill_id ='{{ url("sale/show/")}}/'+obj.id;
                        
                        table.row.add( ['<a target="_blank" href='+bill_id+'>'+obj.id+'</a>','Sale',obj.subtotal,cpaid,obj.duebalance,obj.signedby,obj.date] ).draw();
                        
                        row +='<tr><td><a target="_blank" href='+bill_id+'>'+obj.id+'</td><td>Sale</td><td>'+obj.subtotal+'</td><td>'+cpaid+'</td><td>'+obj.duebalance+'</td><td>'+obj.signedby+'</td><td>'+obj.date+'</td></tr>';
                        if(obj.cashpaid != null)
                            cashPaid =parseInt(cashPaid)+parseInt(obj.cashpaid);
                        if(obj.subtotal != null)
                            total =parseInt(total)+parseInt(obj.subtotal);
                        if(obj.duebalance != null)
                            duebal =parseInt(total)-parseInt(cashPaid);
                    }
                        
                    if('cr_customer' in obj){
                        table.row.add( [obj.id,'Cash Recieved','-',crcpaid,'-','-',obj.cr_date] ).draw();
                        row +='<tr><td>'+obj.id+'</td><td>Cash Recieved</td><td>-</td><td>'+crcpaid+'</td><td>-</td><td>-</td><td>'+obj.cr_date+'</td></tr>';
                        if(obj.cr_cashpaid != null)
                        cashPaid =parseInt(cashPaid)+parseInt(obj.cr_cashpaid);
                    }
                     console.log(obj.id);
                    // obj.id, obj.customer_name, obj.subtotal, obj.cashpaid,obj.duebalance,obj.previousbalance,obj.newbalance,obj.signedby,obj.date
                })
                table.row.add( ['Totals','-',total,cashPaid,duebal,'-','-'] ).draw();
                row +='<tr><td>Totals</td> <td></td> <td>'+total+'</td>  <td>'+cashPaid+'</td><td>'+duebal+'</td><td></td><td></td></tr>';
                
                $('#data').html(row);
                $('#customer_name').val(data[1]);
                //console.log(formatDate(new Date()));
                }
            });
        }
        
    });

    function formatDate(date) {
        // var monthNames = [
        //     "January", "February", "March",
        //     "April", "May", "June", "July",
        //     "August", "September", "October",
        //     "November", "December"
        // ];

        var day = date.getDate();
        var monthIndex = date.getMonth();
        var year = date.getFullYear();

        return day + '/' + monthIndex + '/' + year;
    }

    $(document).on('click','#print',function(){
        var fromDate='';
        var toDate='';
        if($('#datepicker').val() != "")
            fromDate ="From Date : "+$('#datepicker').val();
        if($('#datepicker2').val() != "")
            toDate ="To Date : "+$('#datepicker2').val();
    
        var weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
        var row = "";
        row +="<table style='width:100%;text-align:center;border:1px solid;'><tr>";
        row +="<tr> <th>Employee Name :"+$('#employee_name').val()+"</th><th>   </th><th>"+fromDate+"</th><th>   </th><th>"+toDate+"</th></tr></table>";
        row +="<style>*{ font-size:12px;} td{border:1px solid;} } th{border:1px solid;} .maindiv{width:100%;} .printable{margin-left:-15px;width:100%;float:left;} .col-md-3{ width:25%;float:left;} ul{ list-style:none } li{ border:1px solid grey;backgound:white;} </style>";
        row +="<table style='width:100%;text-align:center;border:1px solid;'><tr>";
        row +="<tr> <th>Product</th><th>Rate/pcs</th><th>Pcs</th><th>Amount</th><th>date</th></tr>";
        $.each(manufactureDetails, function(index, obj) {
            var a = new Date(obj.date);
            row += "<tr><td>" + obj.product + "</td><td>" + obj.rate + "</td><td>" + obj.pcs + "</td><td> " + obj.inlinetotal + "</td><td> " + obj.date + " " + weekday[a.getDay()] + "</td></tr>";
            // $('#employee_name').val(obj.name);
        });
        
        row +="</table>";
        row +="<hr /><div class='maindiv'>"
        row +=$('.printable').html();
        row +="</div>";
        // alert(row);
        PrintElem(row)
    });


function PrintElem(data)
{
    var mywindow = window.open('', 'PRINT', 'height=400,width=600');

    mywindow.document.write('\<html\><head><title></title>');
    mywindow.document.write('</head><body >');
    // mywindow.document.write("<center><img style='width:50%;' src='{{ url('assets/images/imgpsh_fullsize_logo.png') }}'></center><hr>");
    
    mywindow.document.write(data);
    mywindow.document.write("<\/body><\/html>");
    

    mywindow.document.close(); // necessary for IE >= 10
    mywindow.focus(); // necessary for IE >= 10*/

    mywindow.print();
    mywindow.close();

    return true;
}
</script>
@stop