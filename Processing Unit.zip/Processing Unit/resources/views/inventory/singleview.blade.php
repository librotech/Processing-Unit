@extends('layouts.master')

@section('title', 'Accounts System-Inventory')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/inventory/show') }}">All Inventories</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">{{ ucfirst($productname->product_description) }} Inventories</a>
  </li>
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
</ul><br>
    <div class="row"><div class="col-md-8"><h3><b>{{ ucfirst($productname->product_description) }}</b> Inventories</h3></div><div class="col-md-4"></div></div>
    <hr>
    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>Sno.</th>
            <th>Bill No</th>
            <th>Supplier</th>
            <th>Cost Price</th>
            <th>Quantity</th>
            <th>Available Quantity</th>
            <th>Bill Date</th>
        </tr>
        </thead>
        <tbody>
        @foreach($inventories as $inventorie)
        <?php $product=$inventorie->product_description; ?>
        <tr>
          @if($inventorie->status == '')
            <td>{{ $loop->iteration }}</td>
            <td><a href="{{ url('purchase/show/'.$inventorie->inv_bill_id) }}">{{ $inventorie->inv_bill_id  }}</td>
            <td>{{ $inventorie->supplier_name  }}</td>

            <td>{{ $inventorie->inv_cost_price  }}</td>
            <td>{{ $inventorie->inv_purchased_qty  }}</td>
            <td>{{ $inventorie->inv_qty }}</td>
            <td>{{ $inventorie->inv_bill_date  }}</td>
            @endif
        </tr>
        @endforeach
    </tbody>
    <tfoot>
            <tr>
            <th>Sno.</th>
            <th>Bill No</th>
            <th>Supplier</th>
            <th>Cost Price</th>
            <th>Quantity</th>
            <th>Available Quantity</th>
            <th>Bill Date</th>
            </tr>
        </tfoot>
    </table>
@stop
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script type="text/javascript">
$(document).on('keyup', '#search', function(){
    //alert("working");
 var _token = $('input[name="_token"]').val();
    var search=this.value;
          $.ajax({
           type: 'POST',
          url: 'http://127.0.0.1:8000/inventory/search',
          data: { search:search,_token:_token },
          success: function(data){
            $("#results").html(data);
         }
      });
    });
</script>