
@extends('layouts.master')

@section('title', 'Accounts System-Products')

@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link " href="{{ url('finalized_product/show') }}">View Finalized Products</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">Update Finalized Products</a>
  </li>
  
</ul><br>
    <h3>Update Finalized Products</h3>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
     <form action="{{ url('finalized_product/update') }}" method="post">
        {{ csrf_field() }}
        <div class="row">
            @foreach($products as $product)
            <input type="hidden" name="txt_rec_id" value="{{ $product->product_id }}">
        <div class="col-md-3">
            <div class="form-group">
                <label>Product Id</label>
                <input type="text"  onkeypress="return isNumberKey(event,this)" min="0" name="txt_product_id"  value="{{ $product->product_id }}" class="form-control" placeholder="Enter Product Id">
            </div>
            </div><div class="col-md-3">
            <div class="form-group">
                <label>Sale Price</label>
                <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="txt_sale_price"  value="{{ $product->sale_price }}" class="form-control" placeholder="Enter Sale Price">
            </div>
            
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Product name</label>
                <input type="text" name="txt_product_name" value="{{ $product->name }}" class="form-control" placeholder="Enter Product name">
            </div>
        </div><div class="col-md-3">
            <div class="form-group">
                <label>Cost Price</label>
                <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" value="{{ $product->cost_price }}" name="txt_cost_price" class="form-control" placeholder="Enter cost price">
            </div>
            
        </div>
        @endforeach
       
        </div>

        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
        <button class="btn btn-block btn-success">Update</button></div></div>
    </form>

@stop
