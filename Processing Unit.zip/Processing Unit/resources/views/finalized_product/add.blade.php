
@extends('layouts.master')

@section('title', 'Accounts System-Products')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('finalized_product/show') }}">View Finalized Products</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >Add New Product</a>
  </li>
  
</ul><br>
    <h3>Add New Product</h3>
     <a href="{{ url('finalized_product/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Finalized Products</a>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
     <form action="{{ url('finalized_product.store') }}" method="post">
        {{ csrf_field() }}
          <div class="row">
            
             <div class="col-md-3">
                 <label>Raw Products</label>
                 <input class="form-control" required="required" name="txt_product" required="required" id="products"  placeholder="Select raw product" class="form-control" list="product">
                    <datalist id="product">
                    @foreach($products as $product)
                        <option value="{{ $product->product_id }}"><b>{{ $product->product_description }}</b></option>
                    @endforeach
                    </datalist>

             </div>

             <div class="col-md-6"></div>
        </div>
        <br>
        <div class="row">
            <table class="table table-hover order-list">
                <thead>
                <tr>
                    <th>Product Id</th>
                    <th>Product Name</th>
                    <th>Sale Price</th>
                    <th>Weight</th>
                    <th>Cost Price</th>
                   
                    <th>Add More</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>
                    <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" required="required" value="" name="txt_product_id1" class="form-control" placeholder="Enter Product Id" autofocus>
                    </td>

                    <td><input type="text" required="required" name="txt_product_description1" class="form-control" placeholder="Enter Product Name"></td>

                    <td><input type="text" min="0" onkeypress="return isNumberKey(event,this)" required="required" name="txt_sale_price1" class="form-control" placeholder="Enter Sale Price">
                    </td>

                    <td><input type="text" min="0" onkeypress="return isNumberKey(event,this)" required="required" name="txt_weight1" class="form-control" placeholder="Enter Weight "></td>

                    <td><input type="text" min="0" onkeypress="return isNumberKey(event,this)"  name="txt_cost_price1" class="form-control" placeholder="Enter Cost Price"></td>

                    <td><input type="button" id="addrow" value="Add More" class="btn btn-success"></td>

                </tr>
            </tbody>

        </table>
        
        </div>
        
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3"><button class="btn btn-block btn-success">Save</button></div>
        </div>
        </div>
        
    </form>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
$(document).ready(function () {

    var counter = 1;
    $(".order-list").on("keydown",'.qty', function (e) {
        if( e.which == 9 || e.which == 13){
             counter++;
        var newRow = $("<tr>");
        var cols = "";
        cols += '<td><input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" required="required" value="" name="txt_product_id[]" class="form-control" placeholder="Enter Product Id" autofocus></td>';

        cols += '<td><input type="text" required="required" name="txt_product_description[]" class="form-control" placeholder="Enter Product Name"></td>';

        cols += '<td><input type="text" min="0" onkeypress="return isNumberKey(event,this)" required="required" name="txt_sale_price[]" class="form-control" placeholder="Enter Sale Price"></td>';

        cols += '<td><input type="text" min="0" onkeypress="return isNumberKey(event,this)" required="required" name="txt_weight[]" class="form-control" placeholder="Enter Weight "></td>';

        cols +='<td><input type="text" min="0" onkeypress="return isNumberKey(event,this)"  name="txt_cost_price[]" class="form-control" placeholder="Enter Cost Price"></td>';


        cols += '<td><a class="deleteRow btn btn-danger"> x </a></td>';
        newRow.append(cols);
        
        $("table.order-list").append(newRow);
        }
    });
    

    
    $("table.order-list").on("click", "a.deleteRow", function (event) {
        $(this).closest("tr").remove();
    
    });
    $("#addrow").on("click", function () {
        counter++;
        
        var newRow = $("<tr>");
        var cols = "";
          cols += '<td><input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" required="required" value="" name="txt_product_id[]" class="form-control" placeholder="Enter Product Id" autofocus></td>';

        cols += '<td><input type="text" required="required" name="txt_product_description[]" class="form-control" placeholder="Enter Product Name"></td>';

        cols += '<td><input type="text" min="0" onkeypress="return isNumberKey(event,this)" required="required" name="txt_sale_price[]" class="form-control" placeholder="Enter Sale Price"></td>';

        cols += '<td><input type="text" min="0" onkeypress="return isNumberKey(event,this)" required="required" name="txt_weight[]" class="form-control" placeholder="Enter Weight "></td>';

        cols +='<td><input type="text" min="0" onkeypress="return isNumberKey(event,this)"  name="txt_cost_price[]" class="form-control" placeholder="Enter Cost Price"></td>';


        cols += '<td><a class="deleteRow btn btn-danger"> x </a></td>';
        newRow.append(cols);
        
        $("table.order-list").append(newRow);
    });
    
    $("table.order-list").on("click", "a.deleteRow", function (event) {
        $(this).closest("tr").remove();
        
    });
});
    
    function isNumberKey(evt, obj) {

            var charCode = (evt.which) ? evt.which : event.keyCode
            var value = obj.value;
            var dotcontains = value.indexOf(".") != -1;
            if (dotcontains)
                if (charCode == 46) return false;
            if (charCode == 46) return true;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
        }
</script>
