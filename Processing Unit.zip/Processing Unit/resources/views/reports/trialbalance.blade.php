@extends('layouts.master')

@section('title', 'Accounts System-Trial Balance Report')
@section('content')
<ul class="nav nav-tabs">
<li class="nav-item">
<a class="nav-link" href="{{ url('/home') }}">Home</a>
</li>
<li class="nav-item">
<a class="nav-link" href="{{ url('report/view') }}">Reports</a>
</li>
<li class="nav-item">
<a class="nav-link active">Trial Balance Report</a>
</li>
<li class="nav-item">
<a class="nav-link" href="{{ url()->previous() }}">Back</a>
</li>
</ul>
<br>
<div id="HTMLtoPDF" style="width:100%">
<div class="row">
<div class="col-md-4">
<h3>Trial Balance Report</h3>
</div>
<div class="col-md-8">
<div class="form-group">
<form action="{{ url('trialbalancebydate') }}" method="post">
	{{ csrf_field() }}
	<div class="row">
		<div class="col-md-4">
			<input class="form-control" type="text" id="datepicker" autocomplete="off" name="todate" required="required" />
		</div>
		<div class="col-md-3"><button type="submit" class="btn btn-info">Get Report</button></div>
		<div class="col-md-5"></div>
	</div>


</form>
</div>
</div>
</div>


<table class="table table-hover" style="width:100%;text-align:left;">
<tr>
<th>Account Title</th>
<th>Db</th>
<th>Cr</th>
</tr>
@php $debitamount=0;$creditamount=0;$employee_expense=0; @endphp

@foreach($trialbalance as $trialbal)
@if(round($trialbal->balance) != 0)
@if(strpos($trialbal->account_id, 'customer_') !== false)
@if($trialbal->account_type == 1 && $trialbal->balance > 0 || $trialbal->account_type == 5 && $trialbal->balance > 0 && strpos($trialbal->account_id, 'ade_') === false)
@if($trialbal->transection_type != 10)
	<tr>
		@if (strpos($trialbal->coa_title, '_') !== false)
			<td> {{ substr(   $trialbal->coa_title , strrpos(   $trialbal->coa_title , '_') + 1)}} </td>
		@else
			<td> {{ $trialbal->coa_title }} </td>
		@endif

		@if(round($trialbal->balance) < 0) 
			<td>{{ number_format(round($trialbal->balance*-1)) }}</td>
		@else
			<td>{{ number_format(round($trialbal->balance)) }}</td>
		@endif
		<td></td>
		@php
			if($trialbal->balance < 0){$debitamount +=round($trialbal->balance*-1);}else{$debitamount +=$trialbal->balance; }
		@endphp
	</tr>
@endif

@if($trialbal->transection_type == 10)
	@php $employee_expense +=$trialbal->balance;
		$debitamount +=$trialbal->balance;
	@endphp
@endif
@endif



@if($trialbal->account_type == 5 && $trialbal->balance > 0 && strpos($trialbal->account_id, 'ade_') !== false)
<tr>
<td> {{ $trialbal->coa_title }} </td>
<td></td>
@if(round($trialbal->balance) < 0)
<td>{{ number_format(round($trialbal->balance*-1)) }}</td>
@else
<td>{{ number_format(round($trialbal->balance)) }}</td>
@endif
<td></td>
@php
if($trialbal->balance < 0)
{
	$debitamount +=round($trialbal->balance*-1);
}
else
{
	$debitamount +=$trialbal->balance;
}
@endphp
</tr>
@endif



@if($trialbal->account_type == 1 && $trialbal->balance < 0 || $trialbal->account_type == 5 && $trialbal->balance < 0) 
<tr>
<td> {{ $trialbal->coa_title }} </td>
<td></td>
@if(round($trialbal->balance) < 0) 
	<td>{{ number_format(round($trialbal->balance*-1)) }}</td>
@else
	<td>{{ number_format(round($trialbal->balance)) }}</td>
@endif
<td></td>
@php
	if($trialbal->balance < 0)
	{
		$creditamount +=round($trialbal->balance*-1);
	}
	else
	{
		$creditamount +=$trialbal->balance;
	}
@endphp
</tr>
@endif
@if($trialbal->account_type == 3 && $trialbal->balance > 0 || $trialbal->account_type == 4 && $trialbal->balance > 0 || $trialbal->account_type == 2 && $trialbal->balance > 0)
<tr>
<td> {{ $trialbal->coa_title }} </td>
<td></td>
@if(round($trialbal->balance) < 0)
<td>{{ number_format(round($trialbal->balance*-1)) }}</td>
@else
<td>{{ number_format(round($trialbal->balance)) }}</td>
@endif
<td></td>
</tr>
@php
	if($trialbal->balance < 0)
	{
		$creditamount +=round($trialbal->balance*-1);
	}
	else
	{
		$creditamount +=$trialbal->balance;
	}
@endphp
@endif

@if($trialbal->account_type == 3 && $trialbal->balance < 0 || $trialbal->account_type == 4 && $trialbal->balance < 0 || $trialbal->account_type == 2 && $trialbal->balance < 0)
<tr>
	<td> {{ $trialbal->coa_title }} </td>
	@if(round($trialbal->balance) < 0) 
		<td>{{ number_format(round($trialbal->balance*-1)) }}</td>
	@else
		<td>{{ number_format(round($trialbal->balance)) }}</td>
	@endif
	<td></td>
	@php
		if($trialbal->balance < 0)
		{
			$debitamount +=round($trialbal->balance*-1);
		}
		else
		{
			$debitamount +=$trialbal->balance;
		}
	@endphp
	</tr>
@endif
@endif
@if(strpos($trialbal->account_id, 'liability_employee_') !== false)
@if($trialbal->account_type == 1 && $trialbal->balance > 0 || $trialbal->account_type == 5 && $trialbal->balance > 0 && strpos($trialbal->account_id, 'ade_') === false)
	@if($trialbal->transection_type != 10)
		<tr>
			@if (strpos($trialbal->coa_title, '_') !== false)
				<td> {{ substr(   $trialbal->coa_title , strrpos(   $trialbal->coa_title , '_') + 1)}} </td>
			@else
				<td> {{ $trialbal->coa_title }} </td>
			@endif
			@if(round($trialbal->balance) < 0)
			 <td>{{ number_format(round($trialbal->balance*-1)) }}</td>
			@else
				<td>{{ number_format(round($trialbal->balance)) }}</td>
			@endif
				<td></td>
			@php
				if($trialbal->balance < 0)
				{
					$debitamount +=round($trialbal->balance*-1);
				}
				else
				{
					$debitamount +=$trialbal->balance;
				}
				@endphp
		</tr>
	@endif
	@if($trialbal->transection_type == 10)
		@php $employee_expense +=$trialbal->balance;
			$debitamount +=$trialbal->balance;
		@endphp
	@endif
	@endif
	@if($trialbal->account_type == 5 && $trialbal->balance > 0 && strpos($trialbal->account_id, 'ade_') !== false)
		<tr>
			<td> {{ $trialbal->coa_title }} </td>
				<td></td>
					@if(round($trialbal->balance) < 0)
					 <td>{{ number_format(round($trialbal->balance*-1)) }}</td>
					@else
						<td>{{ number_format(round($trialbal->balance)) }}</td>
					@endif
					<td></td>
					@php
						if($trialbal->balance < 0)
						{
							$debitamount +=round($trialbal->balance*-1);
						}
						else
						{
							$debitamount +=$trialbal->balance;
						}
					@endphp
					
			</tr>
		@endif
		@if($trialbal->account_type == 1 && $trialbal->balance < 0 || $trialbal->account_type == 5 && $trialbal->balance < 0)
			<tr>
				<td> {{ $trialbal->coa_title }} </td>
				<td></td>
				@if(round($trialbal->balance) < 0)
				<td>{{ number_format(round($trialbal->balance*-1)) }}</td>
				@else
					<td>{{ number_format(round($trialbal->balance)) }}</td>
				@endif
				<td></td>
				@php
					if($trialbal->balance < 0)
					{
						$creditamount +=round($trialbal->balance*-1);
					}
					else
					{
						$creditamount +=$trialbal->balance;
					}
				@endphp
			</tr>
		@endif
		@if($trialbal->account_type == 3 && $trialbal->balance > 0 || $trialbal->account_type == 4 && $trialbal->balance > 0 || $trialbal->account_type == 2 && $trialbal->balance > 0)
			<tr>
				<td> {{ $trialbal->coa_title }} </td>
				<td></td>
				@if(round($trialbal->balance) < 0)
				 <td>{{ number_format(round($trialbal->balance*-1)) }}</td>
				@else
					<td>{{ number_format(round($trialbal->balance)) }}</td>
				@endif
				<td></td>
			</tr>
			@php
				if($trialbal->balance < 0)
				{
					$creditamount +=round($trialbal->balance*-1);
				}
				else
				{
					$creditamount +=$trialbal->balance; 
				}
			@endphp
		@endif
		@if($trialbal->account_type == 3 && $trialbal->balance < 0 || $trialbal->account_type == 4 && $trialbal->balance < 0 || $trialbal->account_type == 2 && $trialbal->balance < 0) 
		<tr>
			<td> {{ $trialbal->coa_title }} </td>
			@if(round($trialbal->balance) < 0)
				<td>{{ number_format(round($trialbal->balance*-1)) }}</td>
			@else
			<td>{{ number_format(round($trialbal->balance)) }}</td>
			@endif
			<td></td>
			@php
				if($trialbal->balance < 0)
				{
					$debitamount +=round($trialbal->balance*-1);
				}
				else
				{
					$debitamount +=$trialbal->balance;
				}
				@endphp
		</tr>
		@endif
		@endif
		@if($trialbal->account_type == 2 && strpos($trialbal->account_id, 'liability_employee_') === false)
			@if($trialbal->account_type == 1 && $trialbal->balance > 0 || $trialbal->account_type == 5 && $trialbal->balance > 0 && strpos($trialbal->account_id, 'ade_') === false)
				@if($trialbal->transection_type != 10)
					<tr>
						@if (strpos($trialbal->coa_title, '_') !== false)
						<td> {{ substr(   $trialbal->coa_title , strrpos(   $trialbal->coa_title , '_') + 1)}} </td>
						@else
						<td> {{ $trialbal->coa_title }} </td>
						@endif
						@if(round($trialbal->balance) < 0)
						 <td>{{ number_format(round($trialbal->balance*-1)) }}</td>
						@else
						<td>{{ number_format(round($trialbal->balance)) }}</td>
						@endif
						<td></td>
						@php
							if($trialbal->balance < 0)
							{
								$debitamount +=round($trialbal->balance*-1);
							}else
							{
								$debitamount +=$trialbal->balance; 
							}
						@endphp
					</tr>
					@endif
					@if($trialbal->transection_type == 10)
						@php $employee_expense +=$trialbal->balance;
							$debitamount +=$trialbal->balance;
						@endphp
					@endif
		@endif
		@if($trialbal->account_type == 5 && $trialbal->balance > 0 && strpos($trialbal->account_id, 'ade_') !== false)
		<tr>
			<td> {{ $trialbal->coa_title }} </td>
			<td></td>
			@if(round($trialbal->balance) < 0) 
			<td>{{ number_format(round($trialbal->balance*-1)) }}</td>
			@else
			<td>{{ number_format(round($trialbal->balance)) }}</td>
			<td></td>
			@endif
			@php
				if($trialbal->balance < 0)
				{
					$debitamount +=round($trialbal->balance*-1);
				}
				else
				{
					$debitamount +=$trialbal->balance; 
				}
			@endphp
		</tr>
		@endif
		@if($trialbal->account_type == 1 && $trialbal->balance < 0 || $trialbal->account_type == 5 && $trialbal->balance < 0) 
			<tr>
				<td> {{ $trialbal->coa_title }} </td>
				<td></td>
				@if(round($trialbal->balance) < 0) <td>{{ number_format(round($trialbal->balance*-1)) }}</td>
				@else
				<td>{{ number_format(round($trialbal->balance)) }}</td>
				@endif
				<td></td>
				@php
					if($trialbal->balance < 0)
					{
						$creditamount +=round($trialbal->balance*-1);
					}
					else
					{
						$creditamount +=$trialbal->balance;
					}
				@endphp
			</tr>
			@endif
			@if($trialbal->account_type == 3 && $trialbal->balance > 0 || $trialbal->account_type == 4 && $trialbal->balance > 0 || $trialbal->account_type == 2 && $trialbal->balance > 0)
			<tr>
				<td> {{ $trialbal->coa_title }} </td>
					<td></td>
					@if(round($trialbal->balance) < 0)
					 <td>{{ number_format(round($trialbal->balance*-1)) }}</td>
					@else
					<td>{{ number_format(round($trialbal->balance)) }}</td>
					@endif
				<td></td>
			</tr>
			@php
				if($trialbal->balance < 0)
				{
					$creditamount +=round($trialbal->balance*-1);
				}
				else
				{
					$creditamount +=$trialbal->balance;
				}
			@endphp
			@endif
			@if($trialbal->account_type == 3 && $trialbal->balance < 0 || $trialbal->account_type == 4 && $trialbal->balance < 0 || $trialbal->account_type == 2 && $trialbal->balance < 0) 
			<tr>
				<td> {{ $trialbal->coa_title }} </td>
			@if(round($trialbal->balance) < 0) 
			<td>{{ number_format(round($trialbal->balance*-1)) }}</td>
			@else
				<td>{{ number_format(round($trialbal->balance)) }}</td>
			@endif
			<td></td>
			@php
			if($trialbal->balance < 0)
			{
				$debitamount +=round($trialbal->balance*-1);
			}
			else
			{
				$debitamount +=$trialbal->balance; 
			}
			@endphp
		</tr>
		@endif
		@endif
		@if($trialbal->account_type != 2 && strpos($trialbal->account_id, 'liability_employee_') === false && strpos($trialbal->account_id, 'customer_') === false)
			@if($trialbal->account_type == 1 && $trialbal->balance > 0 || $trialbal->account_type == 5 && $trialbal->balance > 0 && strpos($trialbal->account_id, 'ade_') === false)
				@if($trialbal->transection_type != 10)
					<tr>
						@if (strpos($trialbal->coa_title, '_') !== false)
							<td> {{ substr(   $trialbal->coa_title , strrpos(   $trialbal->coa_title , '_') + 1)}} </td>
						@else
							<td> {{ $trialbal->coa_title }} </td>
						@endif
						@if(round($trialbal->balance) < 0)
						 <td>{{ number_format(round($trialbal->balance*-1)) }}</td>
						@else
						<td>{{ number_format(round($trialbal->balance)) }}</td>
						@endif
						<td></td>
						@php
						if($trialbal->balance < 0)
						{
							$debitamount +=round($trialbal->balance*-1);
						}
						else
						{
							$debitamount +=$trialbal->balance;
						}
						@endphp
					</tr>
			@endif
			@if($trialbal->transection_type == 10)
				@php $employee_expense +=$trialbal->balance;
					$debitamount +=$trialbal->balance;
				@endphp
			@endif
		@endif


		@if($trialbal->account_type == 5 && $trialbal->balance > 0 && strpos($trialbal->account_id, 'ade_') !== false)
			<tr>
				<td> {{ $trialbal->coa_title }} </td>
				<td></td>
					@if(round($trialbal->balance) < 0) 
					<td>{{ number_format(round($trialbal->balance*-1)) }}</td>
					@else
					<td>{{ number_format(round($trialbal->balance)) }}</td>
					@endif
					<td></td>
					@php
					if($trialbal->balance < 0)
					{
						$debitamount +=round($trialbal->balance*-1);
					}
					else
					{
						$debitamount +=$trialbal->balance; 
					}
					@endphp
				</tr>
		@endif


		@if($trialbal->account_type == 1 && $trialbal->balance < 0 || $trialbal->account_type == 5 && $trialbal->balance < 0) 
		<tr>
			<td> {{ $trialbal->coa_title }} </td>
			<td></td>
			@if(round($trialbal->balance) < 0)
			<td>{{ number_format(round($trialbal->balance*-1)) }}</td>
			@else
			<td>{{ number_format(round($trialbal->balance)) }}</td>
			@endif
			<td></td>
			@php
				if($trialbal->balance < 0)
				{
					$creditamount +=round($trialbal->balance*-1);
				}
				else
				{
					$creditamount +=$trialbal->balance; 
				}
			@endphp
		</tr>
		@endif
		@if($trialbal->account_type == 3 && $trialbal->balance > 0 || $trialbal->account_type == 4 && $trialbal->balance > 0 || $trialbal->account_type == 2 && $trialbal->balance > 0)
			<tr>
				<td> {{ $trialbal->coa_title }} </td>
				<td></td>
				@if(round($trialbal->balance) < 0) <td>{{ number_format(round($trialbal->balance*-1)) }}</td>
				@else
				<td>{{ number_format(round($trialbal->balance)) }}</td>
				@endif
			</tr>
			@php
			if($trialbal->balance < 0){$creditamount +=round($trialbal->balance*-1);}else{$creditamount +=$trialbal->balance; }
			@endphp
		@endif
		@if($trialbal->account_type == 3 && $trialbal->balance < 0 || $trialbal->account_type == 4 && $trialbal->balance < 0 || $trialbal->account_type == 2 && $trialbal->balance < 0) 
		<tr>
			<td> {{ $trialbal->coa_title }} </td>
			@if(round($trialbal->balance) < 0) <td>{{ number_format(round($trialbal->balance*-1)) }}</td>
			@else
			<td>{{ number_format(round($trialbal->balance)) }}</td>
			@endif
			<td></td>
			@php
			if($trialbal->balance < 0)
			{
				$debitamount +=round($trialbal->balance*-1);
			}
			else
			{
				$debitamount +=$trialbal->balance;
			}
			@endphp
		</tr>
		@endif
		@endif
		@endif
		@endforeach
		<tr>
			<td>Total Wages</td>
			<td>{{ number_format(round($employee_expense)) }} </td>
			<td></td>
		</tr>
		<tr>
			<th>Total</th>
			<th> {{ number_format(round($debitamount)) }} </th>
			<th>{{ number_format(round($creditamount)) }}</th>
		</tr>
	</table>
</div>
<button class="btn btn-success" onclick="HTMLtoPDF()">Generate PDF</button>&nbsp<button onclick="printDiv('HTMLtoPDF')" class="btn btn-success">Print Report</button>
<hr>
<script src="{{ url('/assets/js/jspdf.js') }}"></script>
<script type="text/javascript">
function HTMLtoPDF() {
	var pdf = new jsPDF('p', 'pt', 'letter');
	source = $('#HTMLtoPDF')[0];
	specialElementHandlers = {
		'#bypassme': function(element, renderer) {
			return true
		}
	}
	margins = {
		top: 50,
		left: 60,
		width: 545
	};
	pdf.fromHTML(
		source // HTML string or DOM elem ref.
		, margins.left // x coord
		, margins.top // y coord
		, {
			'width': margins.width // max width of content on PDF
				,
			'elementHandlers': specialElementHandlers
		},
		function(dispose) {
			// dispose: object with X, Y of the last line add to the PDF
			//          this allow the insertion of new lines after html
			pdf.save('trialbal.pdf');
		}
	)
}

function printDiv(divName) {
	var printContents = document.getElementById(divName).innerHTML;
	var originalContents = document.body.innerHTML;
	document.body.innerHTML = printContents;
	window.print();
	document.body.innerHTML = originalContents;
}
</script>
@stop