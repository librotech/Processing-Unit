@extends('layouts.master')

@section('title', 'Accounts System-Reports')

@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">Reports</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    </ul>
<br>
<style type="text/css">
  .links{
    list-style:none;
    background:#6666FF !important;
    color:white;
    padding:5px;
    border-top-right-radius:15px;
    border-bottom-right-radius:15px;
    margin:3px;
    font-size:20px;
    border-top:1px solid white; 
  }
</style>
    <h3>Reports</h3>
    <hr>
    <table class="table table-responsive">
      <a  class="btn btn-warning" href="{{ url('ledger/show') }}">Ledger</a><br><br>
      <a  class="btn btn-warning" href="{{ url('ledgercoareport') }}">Ledger Report by Chart Accounts</a><br><br>
      @if(Auth::user()->role == 1)
      <a  class="btn btn-warning" href="{{ url('profitandlossreport') }}">Profit And Loss Report</a><br><br>
      <a  class="btn btn-warning" href="{{ url('balancesheetreport') }}">Balance Sheet Report</a><br><br>
      <a  class="btn btn-warning" href="{{ url('trialbalance') }}">Trial Balance Report</a><br><br>

      <a  class="btn btn-warning" href="{{ url('dailycashsales') }}">Sales Reports</a><br><br>
      <a  class="btn btn-warning" href="{{ url('dailyexpenses') }}">Expense Reports</a><br><br>
      @endif
      @if(Auth::user()->role == 1)
      <a  class="btn btn-warning" href="{{ url('Employeestitch/show') }}">Number Of Employee Stitchs</a><br><br>
      <a  class="btn btn-warning" href="{{ url('machinestitch/show') }}">Number Of Machine Stitchs</a><br><br>
      @endif
    	
    	
    </table>
@stop
