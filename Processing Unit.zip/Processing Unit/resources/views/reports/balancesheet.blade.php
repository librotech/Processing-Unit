@extends('layouts.master')

@section('title', 'Accounts System-Balance Sheet Report')
@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('report/view') }}">Reports</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">Balance Sheet Report</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    </ul>
<br>
<ul class="nav nav-tabs" role="tablist">
        <!-- <li class="nav-item" >
            <a class="nav-link" href="#" data-toggle="tab" id="daily" role="tab">Daily Balance Sheet</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#" data-toggle="tab" id="weekly" role="tab">Weekly Balance Sheet</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="#" data-toggle="tab" id="monthly" role="tab" >Monthly Balance Sheet</a>
        </li>
        <li class="nav-item"><b>&nbsp&nbspFrom</b>&nbsp</li>
        <li class="nav-item">
            <input type="text" value="{{ date('Y-m-d') }}" readonly="" id="datepicker"  class="form-control">&nbsp
        </li>
        <li class="nav-item"><b>&nbsp&nbspTo</b>&nbsp</li> -->
        <li class="nav-item">
            <input type="text" value="{{ date('Y-m-d') }}" readonly="" id="datepicker2"  class="form-control">&nbsp
        </li>
         
        <li class="nav-item">&nbsp<a href="#" class="btn btn-info" id="datereport">Get Report</a></li>
</ul>
   <div id="HTMLtoPDF">
	<div id="result" style="width:100%;">
		<hr>
		<h5>Balance Sheet Report</h5>
		<table class="table table-hover" style="width:100%;text-align:left;">
		<tr><th>Assets</th><th>  </th></tr>
		<?php
		$asset_total           = 0;
		$capital_total         = 0;
		$liability_total       = 0;
		$acu_expence_total     = 0;
		$employee_liability    = 0;
		$customertotal         = 0;
		$liabilitylessthenzero = 0;
		$otherassets           = 0;
		$totalassets           = 0;
		$finaltotal            = 0;
		$totalPayAdvance       =0;
		$totalCashInHAnd  =0;
		?>
		@foreach($assets as $asset)
			@if($asset->balance > 0)
			@if(strpos($asset->account_id, 'customer_') !== false)
            			<?php
            $customertotal += $asset->balance;
            ?>
            @elseif($asset->account_id == 'padvance101')
               @php $totalPayAdvance  += $asset->balance; @endphp
             @elseif($asset->account_id == 52)
                 @php $totalCashInHAnd  += $asset->balance; @endphp
             
			@else
			<?php
$otherassets += $asset->balance;
?>
		
			@endif
			
			<?php
$asset_total += round($asset->balance);
?>
		    @endif
		@endforeach
		<tr><td>Customers</td><td>{{ number_format(round($customertotal)) }}</td></tr>
		
		<tr><td>Advance Wages</td><td>{{ number_format($totalPayAdvance) }}</td></tr>
		
		<tr><td>Cash in Hand</td><td>{{ number_format($totalCashInHAnd) }}</td></tr>
		<tr><td>Other Assets</td><td>{{ number_format(round($otherassets)) }}</td></tr>
		@foreach($liabilities as $liability)
			@if($liability->balance < 0)
				@if($liability->transection_type != 10)
				<!--<tr><td>{{ $liability->coa_title }}</td><td>{{ number_format(round($liability->balance*-1)) }}</td></tr>-->
				<?php
$liabilitylessthenzero += round($liability->balance * -1);
?> 
				@endif
				
			@endif
			<!--<?php //$invtotal +=round($liability->balance); 
?>-->
		@endforeach
		   <tr><td>Other Liabilities</td><td>{{ number_format($liabilitylessthenzero) }}</td></tr>
		<!--<tr><th>Inventories Total</th><th> {{ number_format($invtotal) }} </th></tr>-->
		<tr><td>Sub Assets Total</td><td> {{ number_format($asset_total)}} </td></tr>
		<tr><td>Accumulative Expenses</td><td>  </td></tr>
		@foreach($acu_expences as $acu_expence)
			<tr><td>{{ $acu_expence->coa_title }}</td><td>{{ number_format($acu_expence->balance) }}</td></tr>
			<?php
$acu_expence_total += round($acu_expence->balance);
?>
		@endforeach

		<tr><td>Accumulative Total</td><td> {{ $acu_expence_total }} </td></tr>
		<?php
$totalassets = $asset_total + $liabilitylessthenzero - $acu_expence_total;
?>
		<tr><th>Assets Total</th><th> {{ number_format($asset_total+$liabilitylessthenzero-$acu_expence_total) }} </th></tr>
		<tr><th><br></th><th><br></th></tr>
		<tr><th>Capital Account</th><td>  </td></tr>
		@foreach($capitals as $capital)
			<tr><td>{{ $capital->coa_title }}</td><td>{{ number_format($capital->balance) }}</td></tr>
			<?php
            $capital_total += round($capital->balance);
?>
		@endforeach

		
	
		<tr><th>Net Profit</th><td><b>{{ number_format(round($netprofit)) }}</b></td></tr>
			<tr><th><br></th><th><br></th></tr>
		<tr><th>Capital Total</th><th> {{ number_format(round($capital_total+$netprofit)) }} </th></tr>
		<tr><th>liability Account</th><td>  </td></tr>
		@foreach($liabilities as $liability)
		   @if($liability->transection_type != 10)
			 @if($liability->balance > 0)
			
				<?php
$liability_total += round($liability->balance);
?>
					@endif
			 @endif
				@if($liability->transection_type == 10)
				<?php
$employee_liability += round($liability->balance);

?>
			@endif
		@endforeach
		<tr><td>Liability Subtotal</td><td>{{ number_format($liability_total) }}</td></tr>
		@foreach($assets as $asset)
			@if($asset->balance < 0)
			<!--<tr><td>{{ $asset->coa_title }}</td><td>{{ number_format(round($asset->balance*-1)) }}</td></tr>-->
			<?php
$otherassets = 0;
$asset_total += round($asset->balance * -1);
$otherassets += round($asset->balance * -1);
$liability_total += round($asset->balance * -1);
?>
			@endif
		@endforeach
		<tr><td>Other Assets</td><td>{{ number_format($otherassets) }}</td></tr>
		<?php
$liability_total = $liability_total + $employee_liability?>
		<tr><td>Employee Liability</td><td> {{ number_format(round($employee_liability)) }} </td></tr>
		<tr><th>Liability Total</th><th> {{ number_format(round($liability_total)) }} </th></tr>
		<tr><th><br></th><th><br></th></tr>
		<tr><th>Final Total</th><th>{{ number_format(round($capital_total+$netprofit+$liability_total)) }}</th></tr>
		
		<?php
$finaltotal = $capital_total + $netprofit + $liability_total;
?>
		<tr><th>Rounding Difference</th><th>{{ round($finaltotal)-round($totalassets) }}</th></tr>
	</table>
	</div>
</div>
<button class="btn btn-success" onclick="HTMLtoPDF()">Generate PDF</button>
<button onclick="printDiv('result')" class="btn btn-success">Print Report</button>
<hr>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
	$(document).on('click','#daily',function(){
		$.ajax({
		  url: '{{ url("dailybalancesheet") }}',
		  type: 'GET',
		  dataType: 'html',
		}).done(function ( data ) {
		  $('#result').html(data);
		});
	});

	$(document).on('click','#weekly',function(){
		$.ajax({
		  url: '{{ url("weeklybalancesheet") }}',
		  type: 'GET',
		  dataType: 'html',
		}).done(function ( data ) {
		  $('#result').html(data);
		});
	});

	$(document).on('click','#monthly',function(){
		
		$.ajax({
		  url: '{{ url("monthlybalancesheet") }}',
		  type: 'GET',
		  dataType: 'html',
		}).done(function ( data ) {
		  $('#result').html(data);
		});
	});

	$(document).on('click','#datereport',function(){
		var _token = $('input[name="_token"]').val();
        var fromdate=$('#datepicker').val();
        var todate=$('#datepicker2').val();

		$.ajax({
		  url: '{{ url("datetodate") }}',
		  type: 'POST',
		  data:{fromdate:fromdate,todate:todate,_token:_token},
		  dataType: 'html',
		}).done(function ( data ) {
			 $('#result').html(data);
		});
	});

</script>
<script src="{{ url('/assets/js/jspdf.js') }}"></script>
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
function HTMLtoPDF(){
var pdf = new jsPDF('p', 'pt', 'letter');
source = $('#HTMLtoPDF')[0];
specialElementHandlers = {
	'#bypassme': function(element, renderer){
		return true
	}
}
margins = {
    top: 50,
    left: 60,
    width: 545
  };
pdf.fromHTML(
  	source // HTML string or DOM elem ref.
  	, margins.left // x coord
  	, margins.top // y coord
  	, {
  		'width': margins.width // max width of content on PDF
  		, 'elementHandlers': specialElementHandlers
  	},
  	function (dispose) {
  	  // dispose: object with X, Y of the last line add to the PDF
  	  //          this allow the insertion of new lines after html
        pdf.save('balancesheet.pdf');
      }
  )		
}

function printDiv(divName){
			var printContents = document.getElementById(divName).innerHTML;
			var originalContents = document.body.innerHTML;
			document.body.innerHTML = printContents;
			window.print();
			document.body.innerHTML = originalContents;
		}
</script>