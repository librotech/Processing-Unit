@extends('layouts.master')

@section('title', 'Accounts System-Cash Sales Report')
<style type="text/css">
    
</style>
@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('report/view') }}">Reports</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">Sales Reports</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    </ul>
<br>
    <h3>Sales Reports</h3>
    <hr>
   <ul class="nav nav-tabs" role="tablist">
        <li class="nav-item" >
            <a class="nav-link" href="#" data-toggle="tab" id="daily" role="tab">Daily Sales</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#" data-toggle="tab" id="weekly" role="tab">Weekly Sales</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="#" data-toggle="tab" id="monthly" role="tab" >Monthly Sales</a>
        </li>
        <li class="nav-item"><b>&nbsp&nbsp&nbspFrom</b>&nbsp&nbsp</li>
        <li class="nav-item">
            <input type="text" value="{{ date('y-m-d') }}" readonly="" id="datepicker"  class="form-control">&nbsp
        </li>
        <li class="nav-item"><b>&nbsp&nbsp&nbspTo</b>&nbsp&nbsp</li>
        <li class="nav-item">
            <input type="text" value="{{ date('y-m-d') }}" readonly="" id="datepicker2"  class="form-control">&nbsp
        </li>
         
        <li class="nav-item">&nbsp<a href="#" class="btn btn-info" id="datereport">Get Report</a></li>
    </ul>
<!-- Tab panes -->
<div class="tab-content">
    <div class="tab-pane active" id="home" role="tabpanel">
    <div >
        <hr>
    <h3 id="heading">Monthly Sales</h3>
    <hr>
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>SNo.</th>
            <th>Invoice No</th>
            <th>Customer</th>
            <th>Amount</th>
            <th>Date</th>
        </tr>
        </thead>
        <tbody id="cashsale">
         <?php $dailytotal =0; ?>
        @foreach($sales as $sale)
        <?php
              $dailytotal +=$sale->total;
        ?>
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $sale->id }}</td>
                <td>{{ $sale->customer_name }}</td>
                <td>{{ $sale->total }}</td>
                
                <td>{{ date('d-m-Y', strtotime($sale->created_at))}}</td>
            </tr>
        
        @endforeach
        <tr><td></td><td></td><td></td><th>Total</th><th><b>{{ $dailytotal }}</b></th></tr>
    </tbody>
    <tfoot>
            <tr>
            <th>SNo.</th>
            <th>Invoice No</th>
            <th>Customer</th>
            <th>Amount</th>
            <th>Date</th>
            </tr>
        </tfoot>
        
    </table>
   
    </div>
    </div>
</div>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">

$(document).ready(function(){
    $('#daily').click(function(){
        $.ajax({
            url:'{{ url("report/dailycashsalereport") }}',
            type:'get',
            datatype:'json',
            success:function(response){
                var count=1;
                var total=0;
                var row="<hr>";
                 $.each(response, function (index, obj) {
                    row += "<tr><td>"+count+"</td><td>"+ obj.id +"</td><td>"+obj.customer_name+"</td><td>"+ obj.total +"</td><td>"+ obj.created_at +"</td></tr>";

                   count++;
                   total =total + obj.total;
                });
                row +="<tr><th></th><th></th><th></th><th>Total</th><th>"+total+"</th></tr>";
                $('#cashsale').html(row);
                $('#heading').html('Daily Sales');
            }

        })
    });

    $('#weekly').click(function(){
        $.ajax({
            url:'{{ url("report/weeklycashsalereport") }}',
            type:'get',
            datatype:'json',
            success:function(response){
                var count=1;
                var total=0;
                var row="";
                 $.each(response, function (index, obj) {
                    row += "<tr><td>"+count+"</td><td>"+ obj.id +"</td><td>"+obj.customer_name+"</td><td>"+ obj.total +"</td><td>"+ obj.created_at +"</td></tr>";

                   count++;
                   total =total + obj.total;
                });
                row +="<tr><th></th><th></th><th></th><th>Total</th><th>"+total+"</th></tr></table>";
                $('#cashsale').html(row);
                $('#heading').html('Weekly Sales');
            }

        })
    });

    $('#monthly').click(function(){
       $.ajax({
            url:'{{ url("report/monthlycashsalereport") }}',
            type:'get',
            datatype:'json',
            success:function(response){
                var count=1;
                var total=0;
                var row="";
                 $.each(response, function (index, obj) {
                    row += "<tr><td>"+count+"</td><td>"+ obj.id +"</td><td>"+obj.customer_name+"</td><td>"+ obj.total +"</td><td>"+ obj.created_at +"</td></tr>";

                   count++;
                   total =total + obj.total;
                });
                row +="<tr><th></th><th></th><th></th><th>Total</th><th>"+total+"</th></tr></table>";
                $('#cashsale').html(row);
                $('#heading').html('Monthly Sales');
            }

        })
    });

    $('#datereport').click(function(){
        var _token = $('input[name="_token"]').val();
        var fromdate=$('#datepicker').val();
        var todate=$('#datepicker2').val();
        $.ajax({
            url:'{{ url("report/datecashsalereport") }}',
            type:'post',
            data:{fromdate:fromdate,todate:todate,_token:_token},
            datatype:'json',
            success:function(response){
                var count=1;
                var total=0;
                var row="";
                 $.each(response, function (index, obj) {
                    row += "<tr><td>"+count+"</td><td>"+ obj.id +"</td><td>"+obj.customer_name+"</td><td>"+ obj.total +"</td><td>"+ obj.created_at +"</td></tr>";

                   count++;
                   total =total + obj.total;
                });
                row +="<tr><th></th><th></th><th></th><th>Total</th><th>"+total+"</th></tr></table>";
                $('#cashsale').html(row);
            }

        })
    });
});

function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;


}
window.onafterprint = function(){
      window.location.reload(true);
 }

</script>