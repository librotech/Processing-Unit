@extends('layouts.master')

@section('title', 'Accounts System-Profit & Loss Report')
<style type="text/css">
    
</style>
@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('report/view') }}">Reports</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">Profit And Loss Report</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    </ul>
<br>
<h3>Profit And Loss Report</h3>
<hr>
 <ul class="nav nav-tabs" role="tablist">
        <!-- <li class="nav-item" >
            <a class="nav-link" href="#" data-toggle="tab" id="daily" role="tab">Daily Report</a>
        </li>
        <li class="nav-item">
            <a class="nav-link " href="#" data-toggle="tab" id="weekly" role="tab">Weekly Report</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="#" data-toggle="tab" id="monthly" role="tab" >Monthly Report</a>
        </li>
        <li class="nav-item"><b>&nbsp&nbsp&nbspFrom</b>&nbsp&nbsp</li>
        <li class="nav-item">
            <input type="text" value="{{ date('Y-m-d') }}" readonly="" id="datepicker"  class="form-control">&nbsp
        </li>
        <li class="nav-item"><b>&nbsp&nbsp&nbspTo</b>&nbsp&nbsp</li> -->
        <li class="nav-item">
            <input type="text" value="{{ date('Y-m-d') }}" readonly="" id="datepicker2"  class="form-control">&nbsp
        </li>
         
        <li class="nav-item">&nbsp<a href="#" class="btn btn-info" id="datereport">Get Report</a></li>
    </ul>
<div id="HTMLtoPDF">
<div id="result">
<h3 id="heading">Monthly Profit And Loss Report</h3><hr> 
<table class="table table-hover" style="width:100%;text-align:left;">
	<tr><th><h5>Income</h5></th><td> </td></tr>
	<?php $total_income=0;$total_expenses=0; ?>
	@foreach($incomes as $income)
		<tr><td>{{$income->coa_title}}</td><td>{{ $income->balance }}</td></tr>
		<?php $total_income +=$income->balance;  ?>
	@endforeach
	<tr><th>Total Income</th><td><b>{{ $total_income }}</b></td></tr>
</table>

<table class="table table-hover" style="width:100%;text-align:left;">
	<tr><th><h5>Sales</h5></th><td> </td></tr>
	<tr><td>Sales</td><td>{{ $credit_sales }}</td></tr>
	<tr><th>Total Sales</th><td><b>{{ $credit_sales+$cash_sales  }}</b></td></tr>
</table>

<table class="table table-hover" style="width:100%;text-align:left;">
	<tr><th><h5>Revenue And Grossprofit</h5></th><td> </td></tr>
	<tr><td>Revenue</td><td><?php echo $credit_sales+$total_income; ?></td></tr>
	<tr><td>Cost Of Sales</td><td><?php echo $totalcos; ?></td></tr>
	<tr><th>Gross Profit</th><td><b><?php echo $cash_sales+$credit_sales+$total_income-$totalcos; ?></b></td></tr>
</table>

<table class="table table-hover" style="width:100%;text-align:left;">
	<tr><th><h5>Expense</h5></th><td> </td></tr>
	@foreach($expenses as $expense)
			<tr><td>{{$expense->coa_title}}</td><td>{{ $expense->balance }}</td>
		<?php $total_expenses +=$expense->balance;  ?>
	@endforeach
	<tr><th>Total Expense</th><td><b>{{ $total_expenses }}</b></td></tr>
</tr>
</table>

<table class="table table-hover" style="width:100%;text-align:left;">
	<tr><th><h5>Net Profit</h5></th><td> </td></tr>
	<tr><th>Net Profit</th><td><b><?php echo $cash_sales+$credit_sales+$total_income-$totalcos-$total_expenses."&nbsp/- Grossprofit-Expense"; ?></b></td></tr>
</table>
</div>
</div>
<button class="btn btn-success" onclick="HTMLtoPDF()">Genrate Pdf</button>
<button onclick="printDiv('result')" class="btn btn-success">Print Report</button>
<hr>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
	$(document).on('click','#daily',function(){
		$.ajax({
		  url: '{{ url("dailyplreport") }}',
		  type: 'GET',
		  dataType: 'html',
		}).done(function ( data ) {
		  $('#result').html(data);
		});
	});

	$(document).on('click','#weekly',function(){
		$.ajax({
		  url: '{{ url("weeklyplreport") }}',
		  type: 'GET',
		  dataType: 'html',
		}).done(function ( data ) {
		  $('#result').html(data);
		});
	});

	$(document).on('click','#monthly',function(){
		$.ajax({
		  url: '{{ url("monthlyplreport") }}',
		  type: 'GET',
		  dataType: 'html',
		}).done(function ( data ) {
		  $('#result').html(data);
		});
		
	});

	$(document).on('click','#datereport',function(){
		var _token = $('input[name="_token"]').val();
        var fromdate=$('#datepicker').val();
        var todate=$('#datepicker2').val();

		$.ajax({
		  url: '{{ url("datetodatepl") }}',
		  type: 'POST',
		  data:{fromdate:fromdate,todate:todate,_token:_token},
		  dataType: 'html',
		}).done(function ( data ) {
			 $('#result').html(data);
		});
	});

</script>
<script src="{{ url('/assets/js/jspdf.js') }}"></script>
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
function HTMLtoPDF(){
var pdf = new jsPDF('p', 'pt', 'letter');
source = $('#HTMLtoPDF')[0];
specialElementHandlers = {
	'#bypassme': function(element, renderer){
		return true
	}
}
margins = {
    top: 50,
    left: 60,
    width: 545
  };
pdf.fromHTML(
  	source // HTML string or DOM elem ref.
  	, margins.left // x coord
  	, margins.top // y coord
  	, {
  		'width': margins.width // max width of content on PDF
  		, 'elementHandlers': specialElementHandlers
  	},
  	function (dispose) {
  	  // dispose: object with X, Y of the last line add to the PDF
  	  //          this allow the insertion of new lines after html
        pdf.save('p&l.pdf');
      }
  )		
}

function printDiv(divName){
			var printContents = document.getElementById(divName).innerHTML;
			var originalContents = document.body.innerHTML;
			document.body.innerHTML = printContents;
			window.print();
			document.body.innerHTML = originalContents;
		}
</script>