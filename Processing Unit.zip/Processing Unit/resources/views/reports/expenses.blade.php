@extends('layouts.master')

@section('title', 'Accounts System-Expense Report')
<style type="text/css">
    
</style>
@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('report/view') }}">Reports</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">Expense Reports</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    </ul>
<br>
    <h3>Expense Reports</h3>
    <hr>
   <ul class="nav nav-tabs" role="tablist">
        <li class="nav-item" >
            <a class="nav-link" href="#" data-toggle="tab" id="daily" role="tab">Daily Expense</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#" data-toggle="tab" id="weekly" role="tab">Weekly Expense</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="#" data-toggle="tab" id="monthly" role="tab" >Monthly Expense</a>
        </li>
        <li class="nav-item"><b>&nbsp&nbsp&nbspFrom</b>&nbsp&nbsp</li>
        <li class="nav-item">
            <input type="text" value="{{ date('y-m-d') }}" readonly="" id="datepicker"  class="form-control">&nbsp
        </li>
        <li class="nav-item"><b>&nbsp&nbsp&nbspTo</b>&nbsp&nbsp</li>
        <li class="nav-item">
            <input type="text" value="{{ date('y-m-d') }}" readonly="" id="datepicker2"  class="form-control">&nbsp
        </li>
         
        <li class="nav-item">&nbsp<a href="#" class="btn btn-info" id="datereport">Get Report</a></li>
    </ul>
<!-- Tab panes -->
<div class="tab-content">
    <div class="tab-pane active" id="home" role="tabpanel">
    <div >
        <hr>
    <h3 id="heading">Monthly Expense</h3>
    <hr>
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
         <th>SNo.</th>
            <th>Expense id</th>
            <th>Expense Amount</th>
            <th>expense type</th>
            <th>Date</th>
        </tr>
        </thead>
    <tbody id="expense">
         <?php $dailytotal =0; ?>
         @foreach($expenses as $expense)
        <?php
              $dailytotal +=$expense->expense_amount;
        ?>
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $expense->id }}</td>
                <td>{{ $expense->expense_amount }}</td>
                <td>{{ $expense->coa_title }}</td>
                
                <td>{{ date('d-m-Y', strtotime($expense->created_at))}}</td>
            </tr>
        
        @endforeach
        <tr><td></td><td></td><td></td><th>Total</th><th><b>{{ $dailytotal }}</b></th></tr>
    </tbody>
    <tfoot>
            <tr>
           <th>SNo.</th>
            <th>Expense id</th>
            <th>Expense Amount</th>
            <th>expense type</th>
            <th>Date</th>
            </tr>
        </tfoot>
        
    </table>
    </div>
    </div>
    </div>
</div>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">

$(document).ready(function(){
    $('#daily').click(function(){
        $.ajax({
            url:'{{ url("report/dailyexpensereport") }}',
            type:'get',
            datatype:'json',
            success:function(response){
                var count=1;
                var total=0;
                var row="<tr><th>SNo.</th><th>Expense id</th><th>Expense Amount</th><th>expense type</th><th>Date</th></tr>";
                 $.each(response, function (index, obj) {
                    row += "<tr><td>"+count+"</td><td>"+ obj.id +"</td><td>"+obj.expense_amount+"</td><td>"+ obj.coa_title +"</td><td>"+ obj.created_at +"</td></tr>";

                   count++;
                  total +=ParsInt(obj.expense_amount);
                });
                row +="<tr><th></th><th></th><th></th><th>Total</th><th>"+total+"</th></tr>";
                $('#expense').html(row);
                $('#heading').html('Daily Expenses');
            }

        })
    });

    $('#weekly').click(function(){
        $.ajax({
            url:'{{ url("report/weeklybalancereport") }}',
            type:'get',
            datatype:'json',
            success:function(response){
                var count=1;
                var total=0;
                var row="<tr> <th>SNo.</th><th>Expense id</th><th>Expense Amount</th><th>expense type</th><th>Date</th></tr>";
                 $.each(response, function (index, obj) {
                    row += "<tr><td>"+count+"</td><td>"+ obj.id +"</td><td>"+obj.expense_amount+"</td><td>"+ obj.coa_title +"</td><td>"+ obj.created_at +"</td></tr>";

                   count++;
                   total +=ParsInt(obj.expense_amount);
                });
                row +="<tr><th></th><th></th><th></th><th>Total</th><th>"+total+"</th></tr>";
                $('#expense').html(row);
                $('#heading').html('Weekly Expenses');
            }

        })
    });

    $('#monthly').click(function(){
       $.ajax({
            url:'{{ url("report/monthlybalancereport") }}',
            type:'get',
            datatype:'json',
            success:function(response){
                var count=1;
                var total=0;
                var row="<tr> <th>SNo.</th><th>Expense id</th><th>Expense Amount</th><th>expense type</th><th>Date</th></tr>";
                 $.each(response, function (index, obj) {
                    row += "<tr><td>"+count+"</td><td>"+ obj.id +"</td><td>"+obj.expense_amount+"</td><td>"+ obj.coa_title +"</td><td>"+ obj.created_at +"</td></tr>";

                   count++;
                   total +=ParsInt(obj.expense_amount);
                });
                row +="<tr><th></th><th></th><th></th><th>Total</th><th>"+total+"</th></tr>";
                $('#expense').html(row);
                $('#heading').html('Monthly Expenses');
            }

        })
    });

    $('#datereport').click(function(){
        var _token = $('input[name="_token"]').val();
        var fromdate=$('#datepicker').val();
        var todate=$('#datepicker2').val();
        $.ajax({
            url:'{{ url("report/dateexpensereport") }}',
            type:'post',
            data:{fromdate:fromdate,todate:todate,_token:_token},
            datatype:'json',
            success:function(response){
                var count=1;
                var total=0;
                var row="<tr> <th>SNo.</th><th>Expense id</th><th>Expense Amount</th><th>expense type</th><th>Date</th></tr>";
                 $.each(response, function (index, obj) {
                    row += "<tr><td>"+count+"</td><td>"+ obj.id +"</td><td>"+obj.expense_amount+"</td><td>"+ obj.coa_title +"</td><td>"+ obj.created_at +"</td></tr>";

                   count++;
                  total +=ParsInt(obj.expense_amount);
                });
                row +="<tr><th></th><th></th><th></th><th>Total</th><th>"+total+"</th></tr>";
                $('#expense').html(row);
            }

        })
    });
});

function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;


}
window.onafterprint = function(){
      window.location.reload(true);
 }

</script>