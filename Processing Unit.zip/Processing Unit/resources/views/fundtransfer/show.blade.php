@extends('layouts.master')

@section('title', 'Accounts System-Fundstransefer')

@section('content')
    <h3>Transfer Fund</h3>
    <hr>
    @if(count($errors) > 0)
    	@foreach($errors->all() as $error)
    		<p class="alert alert-danger">{{ $error }}</p>
    	@endforeach
    @endif
	    @if(session()->has('message.level'))
	    <div class="alert alert-{{ session('message.level') }}"> 
	    {!! session('message.content') !!}
	    </div>
		@endif
    @foreach($funds as $fund)
    <form  method="post">
    	{{ csrf_field() }}
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                <label>From</label>
                <select name="from" class="form-control">
                    <option>{{ $fund->from_coa_id }}</option>
                </select>
            </div>
            </div>
            <div class="col-md-3">
               <h5 style="margin-top:40px;margin-left:60px;"><b >--------></b></h5>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                <label>To</label>
                <select name="to" class="form-control">
                <option>{{ $fund->to_coa_id }}</option>
                </select>
            </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                <label>Ammount</label>
                <input type="number" required="required" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="amount" value="{{ $fund->ammount }}" class="form-control">
            </div>
            </div>
        </div>
    </form>
    @endforeach
@stop
