<!-- @extends('layouts.app') -->
<style type="text/css">
 body a,h1,h2,h3,h4,h5,h6,p,b,span,label,td,th,button,input,canvas {
      font-family: "Work Sans leght" !important;
    }
    form-control{
        background:#385793 !important;
        height:40px !important;
       
    }
    input,button,label{
        font-size:16px !important;
    }
    label{
        color:white;
    }
</style>
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <br><br><br><br><br> <br><br>
            <div class="card card-default" style="height:300px;margin:0 auto;">
                <div class="card-header" style="background:#385793;height:60px;font-size:30px;font-weight:100px;color:#EAEEF3;">Login Form</div>

                <div class="card-body" style="background:#6666FF;">
                    <br>
                    <form class="form-horizontal" method="POST" action="{{ route('login') }}">
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required autofocus>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}> <b>Remember Me</b>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-lg" style="background-color:#385793;width:100px !important; color:#EAEEF3 !important;">
                                    Login
                                </button>

                                <!-- <a class="btn btn-link" href="{{ route('password.request') }}">
                                    <b>Forgot Your Password?</b>
                                </a> -->
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
