@extends('layouts.master')

@section('title', 'Accounts System-Add New Product')

@section('content')
    <h3>All Users</h3> <a href="{{ url('user/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Add New User</a>
    <hr>
   

@stop
