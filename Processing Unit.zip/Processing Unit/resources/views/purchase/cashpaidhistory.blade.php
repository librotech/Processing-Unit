@extends('layouts.master')

@section('title', 'Accounts System-Cash Paid')


@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('coa/show') }}">View Chart Of Account</a>
  </li>
    <li class="nav-item">
    <a class="nav-link active">Cash Paid History</a>
  </li>
  
</ul>
<br>
    <h3>Cash Paid History</h3> 
    <hr>
	<table class="table table-striped table-bordered dataTable" id="example">
        <thead>
    	<tr>
            <th>Sno.</th>
    		<th>invoice No</th>
            <th>Amount</th>
    		<th>Date</th>
    	</tr>
        </thead>
        <tbody>
    	@foreach($cashpaids as $cashpaid)
    		<tr>
    			<td>{{ $loop->iteration }}</td>
    			<td>{{ $cashpaid->id }}</td>
                <td>{{ $cashpaid->cp_cashpaid }}</td>
    			<td>{{ date('d-m-Y', strtotime($cashpaid->created_at))}}</td>
    		</tr>
    		
    	@endforeach
        </tbody>
      <tfoot>
        <tr>
            <th>Sno.</th>
            <th>invoice No</th>
            <th>Amount</th>
            <th>Date</th>
        </tr>
    </tfoot>
    </table>
    {{ $cashpaids->links() }}
@stop
