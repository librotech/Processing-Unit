@extends('layouts.master')

@section('title', 'Accounts System-Purchase')


@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('coa/show') }}">View Chart Of Account</a>
  </li>
    <li class="nav-item">
    <a class="nav-link active">All cashpaids Recipts</a>
  </li>
  
</ul>
<br>
    <h3>All cashpaids Recipts</h3>
    <hr>
	<table class="table table-striped table-bordered dataTable" id="example">
        <thead>
    	<tr>
    		<th>SNo.</th>
            <th>Cash Paid No</th>
    		<th>Purchase Bill Id</th>
            <th>Due Balanse</th>
    		<th>Date</th>
            <th>View</th>
    	</tr>
        </thead>
        <tbody>
        @foreach($cashpaids as $cp)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $cp->id }}</td>
                <td>{{ $cp->bll_id }}</td>
                <td>{{ $cp->duebalance }}</td>
                <td>{{ date('d-m-Y', strtotime($cp->created_at))}}</td>
                <td><a href="{{ url('cashpaid/history/'.$cp->bll_id) }} " class="btn btn-info">View</a></td>
            </tr>
            
        @endforeach
         </tbody>
      <tfoot>
        <tr>
            <th>SNo.</th>
            <th>Cash Paid No</th>
            <th>Purchase Bill Id</th>
            <th>Due Balanse</th>
            <th>Date</th>
            <th>View</th>
        </tr>
    </tfoot>
    </table>
  
@stop
