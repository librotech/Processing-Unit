@extends('layouts.master')

@section('title', 'Accounts System-Chart Of Account')

@section('content')
    <h3>Update Chart Of Account</h3>
    <a href="{{ url('coa/update') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Suppliers</a>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form action="{{ url('coa/update') }}" method="post">
        {{ csrf_field() }}
        @foreach($chartofaccounts  as $chartofaccount)
        <input type="hidden" name="coa_id" value="{{ $chartofaccount->id }}">
        <div class="row">
        <div class="col-md-3">
                <div class="form-group">
                <label>Account id</label>
                <input type="number" required="required" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="txt_acc_id" value="{{ $chartofaccount->coa_id }}" class="form-control" placeholder="Enter Account id">
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Account Title</label>
                <input type="text" required="required" value="{{ $chartofaccount->coa_title }}"  name="txt_acc_title" class="form-control" placeholder="Enter Account Title">
            </div>
        </div>
        <div class="col-md-3">
                <div class="form-group">
                <label>Account Type</label>
                <select class="form-control" name="txt_account_type">
                    <option value="{{ $chartofaccount->account_type }}">
                        @if( $chartofaccount->account_type == 1 )
                            Assets
                        @elseif($chartofaccount->account_type == 2)
                            Liabilities
                        @elseif($chartofaccount->account_type == 3)
                            Capital
                        @elseif($chartofaccount->account_type == 4)
                            Income
                        @elseif($chartofaccount->account_type == 5)
                            Expense
                        @endif
                    </option>
                    <option value="1">Asset</option>
                    <option value="2">Liabilities</option>
                    <option value="3">Capital</option>
                    <option value="4">Income</option>
                    <option value="5">Expense</option>

                </select>
                
                </div>
            </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Account Description</label>
                <textarea class="form-control"  style="overflow:auto;resize:none" rows="3" cols="3" name="account_description">{{ $chartofaccount->coa_description }}</textarea>
            </div> 
        </div>
        </div>
        @endforeach
        <button class="btn btn-block btn-success">Update</button>
    </form>
@stop
