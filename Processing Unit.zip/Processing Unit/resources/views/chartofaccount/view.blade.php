@extends('layouts.master')

@section('title', 'Accounts System-Chart Of Account')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>

  <li class="nav-item">
    <a class="nav-link active" >View Chart Of Account</a>
  </li>
   <li class="nav-item">
    <a class="nav-link" href="{{ url('coa/add') }}">New Chart Of Account</a>
  </li>
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
</ul><br>
    <h3>Chart Of Accounts</h3> <a href="{{ url('coa/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">New Chart Of Account</a>
   
    <hr>
    <div class="row" style="padding:20px;">
        <a href="{{ url('coa/tradepayable') }} " class="btn btn-info btn-xs">Trade Payable</a>&nbsp&nbsp&nbsp
         <a href="{{ url('coa/traderecieveable') }} " class="btn btn-info btn-xs">Trade Recieveable</a>&nbsp&nbsp&nbsp
        <a  href="{{ url('depriciate') }} " class="btn btn-info btn-xs">Depriciate Fixed Asset</a>
    </div>
    <br>
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>Sno</th>
            <th>Account Code</th>
            <th>Title</th>
            <th>Type</th>
            <th>YTD</th>
        </tr>
    </thead>
    <tbody>
        @foreach($chartofaccounts as $chartofaccount)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $chartofaccount->coa_id }}</td>
                <td><a href="{{ url('coa/accountdetails/'.$chartofaccount->coa_id) }}"><?php
                $pos = strrpos($chartofaccount->coa_title, '-');
                $id = $pos === false ? $chartofaccount->coa_title : substr($chartofaccount->coa_title, $pos + 1); 
                echo $id;?>
                   </a></td>
                
                <?php $account_type=""; if($chartofaccount->account_type == 1 ){
                    $account_type="Asset";
                }elseif($chartofaccount->account_type == 2){
                    $account_type="Liability";
                }elseif($chartofaccount->account_type == 3){
                    $account_type="Capital";
                }elseif($chartofaccount->account_type == 4){
                    $account_type="Income";
                }elseif($chartofaccount->account_type == 5){
                    $account_type="Expense";
                }elseif($chartofaccount->account_type = 6){
                    $account_type="Fixed Asset";
                }
                 ?>
                
                <td>{{ $account_type }}</td>
                <td>{{ $chartofaccount->balance }}</td>
                
            </tr>
            
        @endforeach


    </tbody>
    <tfoot>
            <tr>
            <th>Sno.</th>
            <th>Account Code</th>
            <th>Title</th>
            <th>Type</th>
            <th>YTD</th>
            </tr>
        </tfoot>
    </table>    
@stop
